#include "BarClass.h"

BarClass::BarClass(): GameObject()
{
}

BarClass::BarClass(LTexture* image): GameObject(image)
{
    this -> image = image;
}

void BarClass::Render(long int&, SDL_Renderer*)
{

}
BarClass::~BarClass()
{
    //dtor
}
