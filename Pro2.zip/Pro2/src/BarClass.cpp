#include "BarClass.h"

BarClass::BarClass(): GameObject()
{

}

BarClass::BarClass(LTexture* image, LTexture* icon_image): GameObject(image)
{
    this -> image = image;
    this -> icon_image = icon_image;

}

void BarClass::Render(long int&,  SDL_Renderer*)
{

}
BarClass::~BarClass()
{
    //dtor
}
