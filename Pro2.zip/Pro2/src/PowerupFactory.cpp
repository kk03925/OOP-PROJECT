#include "PowerupFactory.h"
#include "HealthPowerup.h"
#include "QuantityPowerup.h"

PowerupFactory::PowerupFactory()
{
    //ctor
}

Powerup* PowerupFactory::GetPowerup(LTexture* image, float x, float y, int type)
{
    if(type == 1)
    {
        powerup = new HealthPowerup(image, x, y);
    }

    else if (type = 2)
    {
        powerup = new QuantityPowerup(image, x, y);
    }
}

PowerupFactory::~PowerupFactory()
{
    //dtor
}
