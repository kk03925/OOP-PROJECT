#include "Player.h"

Player::Player(LTexture* image)
{
    this->image = image;
    //Set sprite clips
    gStandingSpriteClips [ 0 ].x = 48;
    gStandingSpriteClips [ 0 ].y = 65;
    gStandingSpriteClips [ 0 ].w = 128;
    gStandingSpriteClips [ 0 ].h = 327;

    gStandingSpriteClips [ 1 ].x = 2974;
    gStandingSpriteClips [ 1 ].y = 62;
    gStandingSpriteClips [ 1 ].w = 125;
    gStandingSpriteClips [ 1 ].h = 328;

    gWalkingRightSpriteClips[ 0 ].x =   62;
    gWalkingRightSpriteClips[ 0 ].y =   439;
    gWalkingRightSpriteClips[ 0 ].w =  176;
    gWalkingRightSpriteClips[ 0 ].h = 310;

    gWalkingRightSpriteClips[ 1 ].x =   268;
    gWalkingRightSpriteClips[ 1 ].y =   441;
    gWalkingRightSpriteClips[ 1 ].w =  144;
    gWalkingRightSpriteClips[ 1 ].h = 308;

    gWalkingRightSpriteClips[ 2 ].x =   453;
    gWalkingRightSpriteClips[ 2 ].y =   436;
    gWalkingRightSpriteClips[ 2 ].w =  142;
    gWalkingRightSpriteClips[ 2 ].h = 316;

    gWalkingRightSpriteClips[ 3 ].x =   620;
    gWalkingRightSpriteClips[ 3 ].y =   440;
    gWalkingRightSpriteClips[ 3 ].w =  174;
    gWalkingRightSpriteClips[ 3 ].h = 321;

    gWalkingRightSpriteClips[ 4 ].x =   826;
    gWalkingRightSpriteClips[ 4 ].y =   449;
    gWalkingRightSpriteClips[ 4 ].w =  218;
    gWalkingRightSpriteClips[ 4 ].h = 307;

    gWalkingRightSpriteClips[ 5 ].x =   1072;
    gWalkingRightSpriteClips[ 5 ].y =   437;
    gWalkingRightSpriteClips[ 5 ].w =  192;
    gWalkingRightSpriteClips[ 5 ].h =  315;

    gWalkingRightSpriteClips[ 6 ].x =   1313;
    gWalkingRightSpriteClips[ 6 ].y =   439;
    gWalkingRightSpriteClips[ 6 ].w =  164;
    gWalkingRightSpriteClips[ 6 ].h = 308;

    gWalkingRightSpriteClips[ 7 ].x =   1507;
    gWalkingRightSpriteClips[ 7 ].y =   440;
    gWalkingRightSpriteClips[ 7 ].w =  140;
    gWalkingRightSpriteClips[ 7 ].h = 308;

    gWalkingRightSpriteClips[ 8 ].x =   1671;
    gWalkingRightSpriteClips[ 8 ].y =   425;
    gWalkingRightSpriteClips[ 8 ].w =  152;
    gWalkingRightSpriteClips[ 8 ].h = 320;

    gWalkingRightSpriteClips[ 9 ].x =   1852;
    gWalkingRightSpriteClips[ 9 ].y =   417;
    gWalkingRightSpriteClips[ 9 ].w =  185;
    gWalkingRightSpriteClips[ 9 ].h =   327;

    gWalkingRightSpriteClips[ 10 ].x =   2060;
    gWalkingRightSpriteClips[ 10 ].y =   442;
    gWalkingRightSpriteClips[ 10 ].w =  225;
    gWalkingRightSpriteClips[ 10 ].h = 310;

    gWalkingRightSpriteClips[ 11 ].x =   2328;
    gWalkingRightSpriteClips[ 11 ].y =   428;
    gWalkingRightSpriteClips[ 11 ].w =  184;
    gWalkingRightSpriteClips[ 11 ].h = 325;

    gDuckingSpriteClips [ 0 ].x = 1950;
    gDuckingSpriteClips [ 0 ].y = 208;
    gDuckingSpriteClips [ 0 ].w = 139;
    gDuckingSpriteClips [ 0 ].h = 178;

    gDuckingSpriteClips [ 1 ].x = 3140;
    gDuckingSpriteClips [ 1 ].y = 210;
    gDuckingSpriteClips [ 1 ].w = 136;
    gDuckingSpriteClips [ 1 ].h = 178;

    gWalkingLeftSpriteClips[ 0 ].x =   4990;
    gWalkingLeftSpriteClips[ 0 ].y =   435;
    gWalkingLeftSpriteClips[ 0 ].w =  178;
    gWalkingLeftSpriteClips[ 0 ].h = 316;

    gWalkingLeftSpriteClips[ 1 ].x =   4816;
    gWalkingLeftSpriteClips[ 1 ].y =   444;
    gWalkingLeftSpriteClips[ 1 ].w =  149;
    gWalkingLeftSpriteClips[ 1 ].h = 302;

    gWalkingLeftSpriteClips[ 2 ].x =   4636;
    gWalkingLeftSpriteClips[ 2 ].y =   436;
    gWalkingLeftSpriteClips[ 2 ].w =  141;
    gWalkingLeftSpriteClips[ 2 ].h = 318;

    gWalkingLeftSpriteClips[ 3 ].x =   4430;
    gWalkingLeftSpriteClips[ 3 ].y =   440;
    gWalkingLeftSpriteClips[ 3 ].w =  178;
    gWalkingLeftSpriteClips[ 3 ].h = 324;


    gWalkingLeftSpriteClips[ 4 ].x =   4185;
    gWalkingLeftSpriteClips[ 4 ].y =   446;
    gWalkingLeftSpriteClips[ 4 ].w =  216;
    gWalkingLeftSpriteClips[ 4 ].h = 311;

    gWalkingLeftSpriteClips[ 5 ].x =   3962;
    gWalkingLeftSpriteClips[ 5 ].y =   436;
    gWalkingLeftSpriteClips[ 5 ].w =  196;
    gWalkingLeftSpriteClips[ 5 ].h = 319;

    gWalkingLeftSpriteClips[ 6 ].x =   3752;
    gWalkingLeftSpriteClips[ 6 ].y =   443;
    gWalkingLeftSpriteClips[ 6 ].w =  167;
    gWalkingLeftSpriteClips[ 6 ].h = 306;

    gWalkingLeftSpriteClips[ 7 ].x =   3586;
    gWalkingLeftSpriteClips[ 7 ].y =   442;
    gWalkingLeftSpriteClips[ 7 ].w =  137;
    gWalkingLeftSpriteClips[ 7 ].h = 306;

    gWalkingLeftSpriteClips[ 8 ].x =   3406;
    gWalkingLeftSpriteClips[ 8 ].y =   423;
    gWalkingLeftSpriteClips[ 8 ].w =  153;
    gWalkingLeftSpriteClips[ 8 ].h = 324;

    gWalkingLeftSpriteClips[ 9 ].x =   3187;
    gWalkingLeftSpriteClips[ 9 ].y =   415;
    gWalkingLeftSpriteClips[ 9 ].w =  189;
    gWalkingLeftSpriteClips[ 9 ].h = 328;

    gWalkingLeftSpriteClips[ 10 ].x =   2945;
    gWalkingLeftSpriteClips[ 10 ].y =   442;
    gWalkingLeftSpriteClips[ 10 ].w =  226;
    gWalkingLeftSpriteClips[ 10 ].h = 311;

    gWalkingLeftSpriteClips[ 11 ].x =   2720;
    gWalkingLeftSpriteClips[ 11 ].y =   432;
    gWalkingLeftSpriteClips[ 11 ].w =  181;
    gWalkingLeftSpriteClips[ 11 ].h =   320;

    alive = true;
}

void Player::Render(float& frame, SDL_Renderer* gRenderer)
{
    if (alive)
    {
        image->RenderTexture(10,300, gRenderer,&gStandingSpriteClips[0],0, NULL, 1);
    }

}

Player::~Player()
{
    cout<<"Aladdin destroyed"<<endl;
}
