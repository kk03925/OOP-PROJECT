#include "GameScreen.h"

GameScreen::GameScreen(LTexture* image_one, LTexture* image_two, LTexture* image_three):
    Screen(bg_image)
{
    this->bg_image = image_one;
    this-> image_two = image_two;
    this->image_three = image_three;
}
void GameScreen::Render(float& scroll_one, float& scroll_two, float& scroll_three, SDL_Renderer* gRenderer)
{
    bg_image -> RenderTexture( scroll_one, 0, gRenderer, NULL, 0, NULL, 1.25);
    image_two -> RenderTexture( scroll_two, 110, gRenderer, NULL, 0, NULL, 0.8);
    image_three -> RenderTexture( scroll_three, 58, gRenderer, NULL, 0, NULL, 0.9);
}

GameScreen::~GameScreen()
{
    cout<< "Game Screen no more."<<endl;
}
