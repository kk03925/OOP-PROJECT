#include "GameScreen.h"

GameScreen::GameScreen(LTexture* bgImage, LTexture* fontSprite, LTexture* frontImage): Screen(bgImage, fontSprite)
{
    this->bgImage = bgImage;
    fontSprite = NULL;
    this-> frontImage = frontImage;
}
void GameScreen::Render(float& scroll_bg, float& scroll_forward,SDL_Renderer* gRenderer)
{
   // SDL_Rect rect = {0, 0, 1366, 700};
    bgImage -> RenderTexture( scroll_bg, 0, gRenderer, NULL, 0, NULL, 1.25);
    frontImage -> RenderTexture( scroll_forward, 130, gRenderer, NULL, 0, NULL, 1);
}

GameScreen::~GameScreen()
{
    cout<< "Game Screen no more."<<endl;
}
