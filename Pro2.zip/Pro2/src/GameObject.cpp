#include "GameObject.h"

GameObject::GameObject()
{
}


GameObject::GameObject(LTexture* image)
{
    this -> image = image;
}

void GameObject::Render(long int& frame, SDL_Renderer* gRenderer)
{

}

float GameObject::GetX()
{
    return x;
}
float GameObject::GetY()
{
    return y;
}

void GameObject::SetX(int val)
{
    x = x + val;
}


GameObject::~GameObject()
{
    //dtor
}
