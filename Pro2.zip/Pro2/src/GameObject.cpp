#include "GameObject.h"

GameObject::GameObject()
{
}


GameObject::GameObject(LTexture* image)
{
    this -> image = image;
}

void GameObject::Render(long int&, SDL_Renderer* gRenderer)
{

}

float GameObject::GetX()
{
    return x;
}
float GameObject::GetY()
{
    return y;
}


GameObject::~GameObject()
{
    //dtor
}
