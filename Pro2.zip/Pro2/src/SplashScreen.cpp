#include "SplashScreen.h"
#include "Screen.h"

using namespace std;

SplashScreen::SplashScreen(LTexture* bgImage, LTexture* fontSprite) : Screen(bgImage,fontSprite)
{
    this->bgImage = bgImage;
    fontSprite = NULL;
}

void SplashScreen::Render( float & frame,SDL_Renderer* gRenderer)
{
     SDL_Rect rect = {0, 0, 1366, 700};
     bgImage -> RenderTexture( 0, 0,gRenderer, &rect, 0, NULL, 1 );
}

SplashScreen::~SplashScreen()
{
    cout<<"Splash Screen no more"<<endl;
}
