#include "MenuScreen.h"


MenuScreen::MenuScreen(LTexture* bg_image, LTexture* button, LTexture* text_texture) : Screen(bg_image)
{
    this->bg_image = bg_image;
    this->button_sprite = button;
    this -> text_sprite = text_texture;
    float y = 130;
    button_count = 3;
    buttons = new Button[button_count];
    string buttons_text[3] = {"NEW GAME","CONTINUE","  EXIT  "};
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Init(button_sprite, text_sprite, 500, y, buttons_text[i]);
        y = y + 100;
    }
}

void MenuScreen::Render(SDL_Renderer* gRenderer)
{
    SDL_Rect rect = {0, 0, 1024, 576};
    bg_image->RenderTexture( 0, 0,gRenderer, &rect, 0, NULL, 1);
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Render(gRenderer);
    }
}

Button* MenuScreen::GetButtons()  //returns array of buttons
{
    return buttons;
}
int MenuScreen::GetButtonCount() //return the no. of buttons rendered
{
    return button_count;
}
void MenuScreen::ChangeButtonState(int state, int no ) //changes the state of Button on the index
{
    buttons[no].ChangeState(state);
}
void MenuScreen::MouseMotion(int x, int y)
{
    SDL_Rect mouse_rect = {x,y, 1,1};
    for(int i=0; i < button_count; i++)
    {
        SDL_Rect button = {buttons[i].GetX(),buttons[i].GetY(),buttons[i].GetWidth(), buttons[i].GetHeight()};
        //checks if the pointer position lie inside the border of the button
        //then change the state to hover, else to normal

        if (SDL_HasIntersection(&mouse_rect, &button))
        {
            buttons[i].ChangeState(1);
        }

    }
}
void MenuScreen::MouseClick(int x, int y, Mix_Chunk* button_click )
{
    SDL_Rect mouse_rect = {x,y, 1,1};
    for(int i = 0; i < button_count; i++) //loop going through each button index
    {
        SDL_Rect button = {buttons[i].GetX(),buttons[i].GetY(),buttons[i].GetWidth(), buttons[i].GetHeight()};
        if(SDL_HasIntersection(&mouse_rect, &button))
        {
            Mix_PlayChannel(-1, button_click, 0);
            buttons[i].ChangeState(2);
        }
    }
}


MenuScreen::~MenuScreen()
{

    delete[] buttons;
    cout<<"Menu MenuScreen Destroyed"<<endl;
}
