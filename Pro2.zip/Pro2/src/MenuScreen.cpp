#include "MenuScreen.h"
/*
MenuScreen::MenuScreen()
{

}

void MenuScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    bgImage->RenderTexture( 0, 0,gRenderer, NULL, 10);
    buttonScreen->RenderTexture(width/2 - 250,height/2 - 120,gRenderer,NULL);
/*    for(int i=0; i<ButtonCount; i++)
    {
        buttons[i].Render(gRenderer);
    }
}

MenuScreen::~MenuScreen()
{
    //dtor
}
*/
