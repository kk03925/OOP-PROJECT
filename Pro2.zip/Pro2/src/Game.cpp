#include "Game.h"

Game::Game()
{
    player = NULL;
}

Player* Game::NewGame(LTexture* image, LTexture* health_image, LTexture* health_icon,LTexture* milk_bar, LTexture* milk)
{
   // player = new Player(&Aladdin, &health_bar, &health_icon, &quantity_bar, &quantity_icon);
    //player.movement = false;
    //return player;
}



bool Game::CheckCollisionPowerup(Player* player, Powerup* powerup)
{
   /* SDL_Rect player_rect = {(player->(int)GetX()), (player->(int)GetY()),78, 115};
    SDL_Rect powerup_rect = {powerup->(int)GetX(), powerup->(int)GetY(),28,35};

    if (SDL_HasIntersection(&player_rect, &powerup_rect)
    {
        player.SetHealth();
    } */

}

Game::~Game()
{
    //dtor
}
