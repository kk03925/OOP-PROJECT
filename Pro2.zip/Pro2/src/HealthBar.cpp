#include "HealthBar.h"

HealthBar::HealthBar(): BarClass()
{

}

HealthBar::HealthBar(LTexture* image, float x, float y): BarClass(image)
{
    this -> image = image;

}

void HealthBar::Render(long int&, SDL_Renderer* gRenderer)
{
    bar = {x,y, 120, 25};
    image-> RenderTexture(0, 0,gRenderer, &bar, 0, NULL, 1);

}

HealthBar::~HealthBar()
{
    //dtor
}
