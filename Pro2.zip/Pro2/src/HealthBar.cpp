#include "HealthBar.h"

HealthBar::HealthBar(): BarClass()
{

}

HealthBar::HealthBar(LTexture* image, LTexture* health,float x, float y): BarClass(image)
{
    this -> image = image;
    this -> health_icon = health;
}

void HealthBar::Render(long int&, int health, SDL_Renderer* gRenderer)
{
    bar = {x,y, health*100 , 25};
    image-> RenderTexture(0, 0,gRenderer, &bar, 0, NULL, 1);
    health_icon-> RenderTexture(3*100,0, gRenderer,NULL, 0, NULL, 0.06);
}

HealthBar::~HealthBar()
{
    //dtor
}
