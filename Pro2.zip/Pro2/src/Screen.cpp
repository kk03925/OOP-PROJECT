#include "Screen.h"

Screen::Screen(LTexture* bgImage,LTexture* fontSprite)
{
    this->fontSprite = fontSprite;
}

Screen::~Screen()
{
    //dtor
}
