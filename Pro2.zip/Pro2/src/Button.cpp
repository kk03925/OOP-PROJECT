#include "Button.h"

Button::Button()
{
    width=0;
    height=0;
    state = 0;
    word = NULL;
}

Button::Button(LTexture* image, LTexture* text_texture, float x, float y, string text, int type)
{
    state = 0;
    this-> button_image = image;
    this -> text = text;
    this -> text_texture = text_texture;
    this -> type = type;
    if (type ==0)
    {
        word = new Word(text,text_texture,x+(190-((text.size()*43))/2),y+10);
        spriteClips[0].x = 0;
        spriteClips[0].y = 95;
        spriteClips[0].w = 190;
        spriteClips[0].h = 46;
        spriteClips[1].x = 0;
        spriteClips[1].y = 45;
        spriteClips[1].w = 190;
        spriteClips[1].h = 48;
        spriteClips[2].x = 191;
        spriteClips[2].y = 0;
        spriteClips[2].w = 190;
        spriteClips[2].h = 48;
        width = spriteClips[0].w;
        height = spriteClips[0].h;

    }

    else
    {
        word = NULL;
        spriteClips[0].x = 291;
        spriteClips[0].y = 144;
        spriteClips[0].w = 49;
        spriteClips[0].h = 44;
        spriteClips[1].x = 291;
        spriteClips[1].y = 99;
        spriteClips[1].w = 48;
        spriteClips[1].h = 45;
        spriteClips[2].x = 340;
        spriteClips[2].y = 99;
        spriteClips[2].w = 49;
        spriteClips[2].h = 48;
        width = spriteClips[0].w;
        height = spriteClips[0].h;

    }
    this->x = x;
    this-> y = y;
}

void Button::Init(LTexture* image, LTexture* text_texture, float x, float y, string text, int type)
{
     state = 0;
    this-> button_image = image;
    this -> text = text;
    this -> text_texture = text_texture;
    this -> type = type;
    if (type ==0)
    {
        word = new Word(text,text_texture,x+(190-((text.size()*43))/2),y+10);
        spriteClips[0].x = 0;
        spriteClips[0].y = 95;
        spriteClips[0].w = 190;
        spriteClips[0].h = 46;
        spriteClips[1].x = 0;
        spriteClips[1].y = 45;
        spriteClips[1].w = 190;
        spriteClips[1].h = 48;
        spriteClips[2].x = 191;
        spriteClips[2].y = 0;
        spriteClips[2].w = 190;
        spriteClips[2].h = 48;
        width = spriteClips[0].w;
        height = spriteClips[0].h;

    }

    else
    {
        word = NULL;
        spriteClips[0].x = 291;
        spriteClips[0].y = 144;
        spriteClips[0].w = 49;
        spriteClips[0].h = 44;
        spriteClips[1].x = 291;
        spriteClips[1].y = 99;
        spriteClips[1].w = 48;
        spriteClips[1].h = 45;
        spriteClips[2].x = 340;
        spriteClips[2].y = 99;
        spriteClips[2].w = 49;
        spriteClips[2].h = 48;
        width = spriteClips[0].w;
        height = spriteClips[0].h;

    }
    this->x = x;
    this-> y = y;

}

void Button:: Render(SDL_Renderer* gRenderer)
{
    if (type == 0)
    {
        button_image->RenderTexture(x,y, gRenderer, &spriteClips[state], 0, NULL, 1.5);
        word->Render(gRenderer);
    }
    else
    {
        button_image->RenderTexture(x,y, gRenderer, &spriteClips[state], 0, NULL, 0.65);
    }
}

void Button::ChangeState(int val)
{
    this->state = val;
    //cout<<state<<endl;
}

int Button::GetX()
{
    return x;
}

int Button::GetY()
{
    return y;
}

int Button::GetWidth()
{
    return width;
}

int Button::GetHeight()
{
    return height;
}

string Button::GetText()
{
    return text;
}

int Button::GetState()
{
    return this->state;

}
Button::~Button()
{
    cout <<"Button " << text << " is destroyed" << endl;
    if (word != NULL)
    {
        delete word;
        word = NULL;
    }
}
