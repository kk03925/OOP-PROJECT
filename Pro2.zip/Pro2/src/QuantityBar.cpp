#include "QuantityBar.h"

QuantityBar::QuantityBar(): BarClass()
{

}

QuantityBar::QuantityBar(LTexture* image, LTexture* milk, float x, float y): BarClass(image)
{
    this -> image = image;
    this -> milk = milk;

}

void QuantityBar::Render(long int&, int quantity, SDL_Renderer* gRenderer)
{
    bar = {x,y, quantity*25 , 25};
   // icon = {25,20*25,10, 25};
    image-> RenderTexture(0,25,gRenderer, &bar, 0, NULL, 1);
    milk-> RenderTexture(20*25,25,gRenderer, NULL, 0, NULL, 0.1);

}

QuantityBar::~QuantityBar()
{
    //dtor
}

