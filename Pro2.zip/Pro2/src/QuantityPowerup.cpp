#include "QuantityPowerup.h"

QuantityPowerup::QuantityPowerup(): Powerup()
{
    //ctor
}

QuantityPowerup::QuantityPowerup(LTexture* image, float x, float y): Powerup(image, x ,y)
{
    this-> image = image;
    this -> x = x;
    this -> y = y;
    type = "quantity";
}

void QuantityPowerup:: Render(long int& frame, SDL_Renderer* gRenderer )
{
    image->RenderTexture(x+scroll, y,gRenderer, NULL , 0, NULL, 1);
}

QuantityPowerup::~QuantityPowerup()
{
    //dtor
}
