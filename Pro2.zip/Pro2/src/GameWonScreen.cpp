#include "GameWonScreen.h"

GameWonScreen::GameWonScreen(LTexture* bg_image, LTexture* button, LTexture* text_texture) : MenuScreen(bg_image, button, text_texture)
{
    this->bg_image = bg_image;
    this->button_sprite = button;
    this -> text_sprite = text_texture;
    float y = 280;
    button_count = 2;
    buttons = new Button[button_count];
    string buttons_text[2] = {"NEW GAME","  MENU  "};
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Init(button_sprite, text_sprite, 350, y, buttons_text[i], 0);
        y = y + 100;
    }
}


GameWonScreen::~GameWonScreen()
{
    delete[] buttons;
    cout<<"Game Over GameWonScreen Destroyed"<<endl;
}
