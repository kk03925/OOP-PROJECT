#ifndef BUTTON_H
#define BUTTON_H
#include "LTexture.h"


enum State{Normal, Hover, Clicked};

class Button
{
    public:
        Button(LTexture*);
        void Render(LTexture*);
        virtual ~Button();

    protected:

    private:
        int width;
        int height;
        int state;
        SDL_Rect spriteClips[3]; //sprite clips for each state of the button
        LTexture* button_image; //Texture of image consisting of Buttons


};

#endif // BUTTON_H
