#ifndef PLAYER_H
#define PLAYER_H
#include "LTexture.h"


class Player
{
    public:
        Player(LTexture*);
        void Render( float&, SDL_Renderer*);
        virtual ~Player();

    protected:

    private:
        LTexture* image;  //player sprite sheet
        bool alive;
        SDL_Rect gWalkingRightSpriteClips[ 12 ];
        SDL_Rect gWalkingLeftSpriteClips[ 12 ];
        SDL_Rect gThrowingLeftSpriteClips[ 4 ];
        SDL_Rect gThrowingRightSpriteClips[ 4 ];
        SDL_Rect gDuckingSpriteClips[ 1 ];
        SDL_Rect gStandingSpriteClips [ 2];
};

#endif // PLAYER_H
