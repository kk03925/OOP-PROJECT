#ifndef PLAYER_H
#define PLAYER_H
#include "GameObject.h"
#include "QuantityBar.h"
#include "HealthBar.h"


class Player: public GameObject
{
   public:
        Player(LTexture*, LTexture*, LTexture*, LTexture*, LTexture*);
        void Render(long int&, SDL_Renderer*);
        virtual ~Player();
        int direction = 0;
        int AnimationFrame = 0;
        bool movement;
        void handleEvent( SDL_Event& e );
        void move();
        void SetHealth();
        void SetQuantity();
        static const int PlayerVelocity = 2;

    private:
        bool alive;
		int mVelX = 0;
		int health;
		int milk_quantity;
		HealthBar* health_bar;
		QuantityBar* qauntity_bar;
		LTexture* bar1;
		LTexture* bar2;
		LTexture* health_icon;
		LTexture* milk;
        SDL_Rect gWalkingRightSpriteClips[ 12 ];
        SDL_Rect gWalkingLeftSpriteClips[ 12 ];
        SDL_Rect gThrowingLeftSpriteClips[ 4 ];
        SDL_Rect gThrowingRightSpriteClips[ 4 ];
        SDL_Rect gDuckingSpriteClips[ 1 ];
        SDL_Rect gStandingSpriteClips [ 2];
};

#endif // PLAYER_H
