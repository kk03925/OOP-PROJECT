#ifndef PAUSEQUITSCREEN_H
#define PAUSEQUITSCREEN_H

#include "MenuScreen.h"

class PauseQuitScreen: public MenuScreen
{
    public:
        PauseQuitScreen(LTexture*, LTexture*, LTexture*);
        void Render(SDL_Renderer*);
        virtual ~PauseQuitScreen();

    protected:

    private:
};

#endif // PAUSEQUITSCREEN_H
