#ifndef SCREEN_H
#define SCREEN_H
#include "LTexture.h"

class Screen
{
    public:
        Screen(LTexture*,LTexture*);
        virtual ~Screen();

    protected:

    private:
        LTexture* bgImage;    //background image of the screen
        LTexture* fontSprite;  //image consisting of fonts, and buttons
};

#endif // SCREEN_H
