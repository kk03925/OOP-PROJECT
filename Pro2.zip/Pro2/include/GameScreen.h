#ifndef GAMESCREEN_H
#define GAMESCREEN_H
#include "LTexture.h"
#include "Screen.h"


class GameScreen: public Screen
{
    public:
        GameScreen(LTexture*, LTexture*, LTexture*);
        void Render( float& scroll_bg, float& scroll_forward, SDL_Renderer* gRenderer);
        virtual ~GameScreen();

    protected:

    private:
        LTexture* bgImage;    //background image of the screen
        LTexture* fontSprite;  //image consisting of fonts, and buttons
        LTexture* frontImage; //front image with poles to create parallax effect
};

#endif // GAMESCREEN_H
