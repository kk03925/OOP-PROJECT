#ifndef BARCLASS_H
#define BARCLASS_H
#include "GameObject.h"

class BarClass: public GameObject
{
    public:
        BarClass();
        BarClass(LTexture*);
        void Render(long int&, SDL_Renderer*);
        virtual ~BarClass();

    protected:
        SDL_Rect bar;
    private:


};

#endif // BARCLASS_H
