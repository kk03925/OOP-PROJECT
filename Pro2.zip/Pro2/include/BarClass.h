#ifndef BARCLASS_H
#define BARCLASS_H
#include "GameObject.h"

class BarClass: public GameObject
{
    public:
        BarClass();
        BarClass(LTexture*, LTexture*);
        virtual void Render(long int&, SDL_Renderer*);
        virtual ~BarClass();

    protected:
        SDL_Rect bar;
        SDL_Rect icon;
        LTexture* icon_image;

};

#endif // BARCLASS_H
