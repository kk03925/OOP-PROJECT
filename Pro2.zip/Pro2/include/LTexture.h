#ifndef LTexture_H
#define LTexture_H
#include <SDL.h>
#include<SDL_image.h>
#include<iostream>
#include<stdio.h>
using namespace std;

class LTexture
{
    public:
        LTexture();
        virtual ~LTexture();
        void SetBlendMode(SDL_BlendMode blending);
        void SetAlpha(Uint8 alpha);
        bool LoadFromFile(string, SDL_Renderer*, bool flagColorKey = true, Uint8 redColorKey = 0,
                          Uint8 greenColorKey = 0xFF, Uint8 blueColorKey = 0xFF);        ///takes arguments to ColorKey
        void RenderTexture(int, int, SDL_Renderer*, SDL_Rect*, double, SDL_Point*,float);
        void Free();
        int GetHeight();
        int GetWidth();
        int width;
        int height;
    protected:

    private:
        SDL_Texture* texture;

};

#endif // LTexture_H
