#ifndef WORD_H
#define WORD_H
#include "Character.h"
#include "LTexture.h"

class Word
{
    public:
        Word();
        Word(string, LTexture*, float, float);
        virtual ~Word();
        void Render(SDL_Renderer*); //to draw the word on screen
        int GetLength();
        int GetWidth();
        void ChangeWord(std::string);
        string GetText();


    protected:

    private:
        int x;
        int y;
        string text; //text of the word
        int word_len;  //length of the word
        int width;   //width of the word
        int height; //height of the word
        LTexture* image;
        Character* characters;
};

#endif // WORD_H
