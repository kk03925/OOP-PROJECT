#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H
#include "Ltexture.h"
#include "Screen.h"


class SplashScreen: public Screen
{
    public:
        SplashScreen(LTexture*,LTexture*);
        virtual ~SplashScreen();
        void Render(float& frame,SDL_Renderer* gRenderer);

    protected:

    private:
        LTexture* bgImage;    //background image of the screen
        LTexture* fontSprite;  //image consisting of fonts, and buttons
};

#endif // SPLASHSCREEN_H
