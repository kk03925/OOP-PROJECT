#ifndef HEALTHBAR_H
#define HEALTHBAR_H
#include "BarClass.h"

class HealthBar: public BarClass
{
    public:
        HealthBar();
        HealthBar(LTexture*, LTexture*,float, float);
        void Render(long int&, int, SDL_Renderer*);
        void operator = (const HealthBar& cpy);
        virtual ~HealthBar();
};

#endif // HEALTHBAR_H
