#ifndef HEALTHBAR_H
#define HEALTHBAR_H
#include "BarClass.h"

class HealthBar: public BarClass
{
    public:
        HealthBar();
        HealthBar(LTexture*, float, float);
        void Render(long int&, SDL_Renderer*);
        virtual ~HealthBar();

    protected:

    private:
};

#endif // HEALTHBAR_H
