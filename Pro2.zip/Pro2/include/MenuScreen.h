#ifndef MENUSCREEN_H
#define MENUSCREEN_H
/*
class MenuScreen
{
    public:
        MenuScreen(LTexture*,LTexture*,LTexture*);
        virtual ~MenuScreen();
        void Render(long int& frame, SDL_Renderer*);

    private:
        LTexture* buttonScreen; //the small screen over which buttons are drawn

}; */

#endif // MENUSCREEN_H
