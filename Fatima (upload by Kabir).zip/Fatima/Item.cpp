#include "Item.h"

Item::Item(LTexture* image,float x, float y,float worldX,float worldY) : Object(image,x,y,worldX,worldY)
{
    //ctor
}

Item::~Item()
{
    //dtor
}
