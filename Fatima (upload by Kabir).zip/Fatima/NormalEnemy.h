#ifndef NORMALENEMY_H
#define NORMALENEMY_H
#include "Enemy.h"



class NormalEnemy : public Enemy
{
    public:
        NormalEnemy(LTexture*,float,float,float,float);
        ~NormalEnemy();
        void Attack(float);
        void Render (long int&, SDL_Renderer*);

    private:

};

#endif // NORMALENEMY_H
