#ifndef ENEMY_H
#define ENEMY_H
#include "LTexture.h"
#include "Object.h"

class Enemy : public Object
{
    public:
        Enemy(LTexture*,float,float,float,float);
        ~Enemy();
        virtual void Attack(float) = 0;
        virtual void Render(long int&, SDL_Renderer*);

    protected:
        int direction;

};

#endif // ENEMY_H
