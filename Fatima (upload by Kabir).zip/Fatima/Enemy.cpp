#include "Enemy.h"

Enemy::Enemy(LTexture* image,float x, float y,float worldX,float worldY) : Object(image,x,y,worldX,worldY) //Specifying k object ka ye wala constructor call ho
{
    this->image = image;
    this->x = x;
    this->y = y;
    this->WorldX = worldX;
    this->WorldY = worldY;
    alive =true;

}

Enemy::~Enemy()
{
    //dtor
}




