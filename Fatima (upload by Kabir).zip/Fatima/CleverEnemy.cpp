#include "CleverEnemy.h"
#include "Player.h"
#include "math.h"

CleverEnemy::CleverEnemy(LTexture* image,float x,float y,float worldx,float worldy) : Enemy(image,x,y,worldx,worldy)
{
    cout<<WorldX<<endl;
    cout<<WorldY<<endl;

    type=1;
    damageCaused=100;
    colRecWidth = 94;
    colRecHeight = 140;
    direction = 1;
    AnimationFrame = 0;

    ifThrowing= false;


    gWalkingRightSpriteClips [0].x = 1216;
    gWalkingRightSpriteClips [0].y = 1845;
    gWalkingRightSpriteClips [0].w = 92;
    gWalkingRightSpriteClips [0].h = 140;

    gWalkingRightSpriteClips [1].x = 1308;
    gWalkingRightSpriteClips [1].y = 1845;
    gWalkingRightSpriteClips [1].w = 96;
    gWalkingRightSpriteClips [1].h = 140;

    gWalkingRightSpriteClips [2].x = 1404;
    gWalkingRightSpriteClips [2].y = 1845;
    gWalkingRightSpriteClips [2].w = 100;
    gWalkingRightSpriteClips [2].h = 140;

    gWalkingRightSpriteClips [3].x = 1504;
    gWalkingRightSpriteClips [3].y = 1845;
    gWalkingRightSpriteClips [3].w = 105;
    gWalkingRightSpriteClips [3].h = 140;

    gWalkingRightSpriteClips [4].x = 1609;
    gWalkingRightSpriteClips [4].y = 1845;
    gWalkingRightSpriteClips [4].w = 91;
    gWalkingRightSpriteClips [4].h = 140;

    gWalkingRightSpriteClips [5].x = 1700;
    gWalkingRightSpriteClips [5].y = 1845;
    gWalkingRightSpriteClips [5].w = 87;
    gWalkingRightSpriteClips [5].h = 140;

    gWalkingRightSpriteClips [6].x = 1787;
    gWalkingRightSpriteClips [6].y = 1845;
    gWalkingRightSpriteClips [6].w = 98;
    gWalkingRightSpriteClips [6].h = 140;

    gWalkingRightSpriteClips [7].x = 1885;
    gWalkingRightSpriteClips [7].y = 1845;
    gWalkingRightSpriteClips [7].w = 93;
    gWalkingRightSpriteClips [7].h = 140;

    gWalkingLeftSpriteClips [0].x = 773;
    gWalkingLeftSpriteClips [0].y = 1815;
    gWalkingLeftSpriteClips [0].w = 78;
    gWalkingLeftSpriteClips [0].h = 112;

    gWalkingLeftSpriteClips [1].x = 668;
    gWalkingLeftSpriteClips [1].y = 1825;
    gWalkingLeftSpriteClips [1].w = 90;
    gWalkingLeftSpriteClips [1].h = 105;

    gWalkingLeftSpriteClips [2].x = 565;
    gWalkingLeftSpriteClips [2].y = 1816;
    gWalkingLeftSpriteClips [2].w = 93;
    gWalkingLeftSpriteClips [2].h = 117;

    gWalkingLeftSpriteClips [3].x = 463;
    gWalkingLeftSpriteClips [3].y = 1807;
    gWalkingLeftSpriteClips [3].w = 102;
    gWalkingLeftSpriteClips [3].h = 131;

    gWalkingLeftSpriteClips [4].x = 371;
    gWalkingLeftSpriteClips [4].y = 1810;
    gWalkingLeftSpriteClips [4].w = 93;
    gWalkingLeftSpriteClips [4].h = 121;

    gWalkingLeftSpriteClips [5].x = 291;
    gWalkingLeftSpriteClips [5].y = 1826;
    gWalkingLeftSpriteClips [5].w = 81;
    gWalkingLeftSpriteClips [5].h = 106;

    gWalkingLeftSpriteClips [6].x = 195;
    gWalkingLeftSpriteClips [6].y = 1816;
    gWalkingLeftSpriteClips [6].w = 78;
    gWalkingLeftSpriteClips [6].h = 113;

    gWalkingLeftSpriteClips [7].x = 91;
    gWalkingLeftSpriteClips [7].y = 1820;
    gWalkingLeftSpriteClips [7].w = 89;
    gWalkingLeftSpriteClips [7].h = 119;

    gThrowingSpriteClips [0].x = 232;
    gThrowingSpriteClips [0].y = 1674;
    gThrowingSpriteClips [0].w = 117;
    gThrowingSpriteClips [0].h = 119;

    gThrowingSpriteClips [1].x = 1834;
    gThrowingSpriteClips [1].y = 1717;
    gThrowingSpriteClips [1].w = 113;
    gThrowingSpriteClips [1].h = 121;



    alive = true;

}

void CleverEnemy::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (frame % 200 == 0)
    {
        AnimationFrame++; //to control speed of the clips rendering of the ghosts
    }

    if (alive)
    {
        if (ifThrowing == false)
        {
            if (direction==0)
            {
                cout<<alive<<endl;
                cout<<"Rendering"<<endl;
                image->RenderTexture(x,y, gRenderer,&gWalkingRightSpriteClips[AnimationFrame % 8],0, NULL, 1);
                const SDL_Rect enemyRect= {x , y, 100, 140};
                SDL_RenderDrawRect(gRenderer, &enemyRect);
            }
            else if (direction == 1)
            {
                cout<<alive<<endl;
                cout<<"Rendering"<<endl;
                image->RenderTexture(x,y, gRenderer,&gWalkingLeftSpriteClips[AnimationFrame % 8],0, NULL, 1);
                const SDL_Rect enemyRect= {x , y, 100, 140};
                SDL_RenderDrawRect(gRenderer, &enemyRect);
            }
        }
        else
        {
                image->RenderTexture(x,y, gRenderer,&gThrowingSpriteClips[direction],0, NULL, 1);
        }
    }

    if (AnimationFrame >= 8)
    {
        AnimationFrame = 0;
    }
}


void CleverEnemy::Attack(float)
{

}

CleverEnemy::~CleverEnemy()
{

}

void CleverEnemy::Move(int direction)
{
    if (direction == 1)
    {
        WorldX -=WORLD_COORD_CHANGE_PER_CLICK;
        x -=0.5;
    }

    else if (direction == 1)
    {
        WorldX +=WORLD_COORD_CHANGE_PER_CLICK;
        x +=0.5;
    }

}

void CleverEnemy::AladdinTracker(float AladdinX,float AladdinY)
{
    if (AladdinX<WorldX)
    {
        if (WorldX - AladdinX <= 100)
        {
            ifThrowing = true;
        }
        else
        {
            ifThrowing = false;
            direction = 1;
            Move(direction);
        }
    }
    else if (AladdinX>WorldX)
    {
        if (AladdinX-WorldX <=100)
        {
            ifThrowing = true;
        }
        else
        {
            ifThrowing = false;
            direction = 0;
            WorldX+=0.5;
            x+=0.5;
        }

    }
}
