#include "NormalEnemy.h"


NormalEnemy::NormalEnemy(LTexture* image,float x,float y,float worldx,float worldy) : Enemy(image,x,y,worldx,worldy)
{

    gThrowingRightSpriteClips [0].x = 35;
    gThrowingRightSpriteClips [0].y = 501;
    gThrowingRightSpriteClips [0].w = 102;
    gThrowingRightSpriteClips [0].h = 203;

    gThrowingRightSpriteClips [1].x = 152;
    gThrowingRightSpriteClips [1].y = 580;
    gThrowingRightSpriteClips [1].w = 154;
    gThrowingRightSpriteClips [1].h = 126;

    alive = true;
    health = 1;
    damageCaused = 0.5;

}
void NormalEnemy::Attack(float worldx)
{
    if (this->x - worldx < 100)
    {
        cout<<"in range"<<endl;
    }

}

NormalEnemy::~NormalEnemy()
{

}
