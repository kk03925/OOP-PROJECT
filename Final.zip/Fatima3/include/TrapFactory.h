#ifndef TRAPFACTORY_H
#define TRAPFACTORY_H
#include "Traps.h"

class TrapFactory
{
    public:
        TrapFactory();
        Trap* GetTrap(LTexture*, float, float, int);
        virtual ~TrapFactory();

    protected:

    private:
        Trap* trap;
};

#endif // TRAPFACTORY_H
