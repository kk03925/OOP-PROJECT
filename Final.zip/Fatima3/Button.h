#ifndef BUTTON_H
#define BUTTON_H
#include "LTexture.h"
#include "Word.h"
#include <string>

class Button
{
    public:
        Button();
        Button(LTexture*, LTexture*, float, float, string, int type);
        void Init(LTexture*, LTexture*, float, float, string, int type);
        void Render(long int&, SDL_Renderer*);
        int GetWidth();
        int GetHeight();
        float GetX();
        float GetY();
        void ChangeState(int); //changes state of the button
        string GetText();
        int GetState();
        virtual ~Button();

    protected:

    private:
        Word* word; //word to be rendered
        int width;
        int height;
        int type;
        float x;
        float y;
        int state;
        string text;
        SDL_Rect spriteClips[3]; //sprite clips for each state of the button
        LTexture* button_image; //texture containing buttons
        LTexture* text_texture; //Texture of image consisting of Buttons


};

#endif // BUTTON_H
