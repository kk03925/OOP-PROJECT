#ifndef QUANTITYBAR_H
#define QUANTITYBAR_H
#include "BarClass.h"


class QuantityBar: public BarClass
{
    public:
        QuantityBar();
        void Render(long int&, int, SDL_Renderer*);
        QuantityBar(LTexture*, LTexture*, float, float);
        void operator = (const QuantityBar& cpy);
        virtual ~QuantityBar();

    protected:

    private:
        LTexture* milk;
};

#endif // QUANTITYBAR_H
