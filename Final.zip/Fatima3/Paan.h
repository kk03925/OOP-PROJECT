#ifndef PAAN_H
#define PAAN_H
#include "Traps.h"

class Paan : public Traps
{
    public:
        Paan();
        Paan(LTexture*, float, float);
        void Render(long int&, SDL_Renderer*);
        virtual ~Paan();

};

#endif // PAAN_H
