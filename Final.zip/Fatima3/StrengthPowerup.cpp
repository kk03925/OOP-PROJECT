#include "StrengthPowerup.h"

StrengthPowerup::StrengthPowerup(LTexture* image, float x, float y): Powerup(image, x ,y)
{
    this-> image = image;
    this -> x = x;
    this -> y = y;
    colRecWidth = 32;
    colRecHeight = 32;
    type = STRENGTHPOWERUP;
}

void StrengthPowerup::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if( scroll <= -x + 1000)
    {
        x = x - 1;
    }
    image->RenderTexture(x+scroll, y,gRenderer, NULL , 0, NULL, 3);
}



StrengthPowerup::~StrengthPowerup()
{
    //dtor
}
