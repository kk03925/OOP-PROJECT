#ifndef TRAPS_H
#define TRAPS_H
#include "Object.h"
#include "LTexture.h"

class Traps : public Object
{
    public:
        Traps();
        Traps(LTexture*, float, float);
        virtual void Render(long int&, SDL_Renderer*) = 0;
        int GetStrType();
        void SetScroll(float);
        virtual ~Traps();

    protected:
        float scroll;
};

#endif // TRAPS_H
