#include "Screen.h"

Screen::Screen(LTexture* bg_image)
{
  this -> bg_image = bg_image;
}

void Screen::Render(SDL_Renderer* gRenderer)
{
    bg_image -> RenderTexture( 0, 0, gRenderer, NULL, 0, NULL, 1 );
}


Screen::~Screen()
{
    //dtor
}
