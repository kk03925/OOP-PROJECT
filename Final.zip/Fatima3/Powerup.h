#ifndef POWERUP_H
#define POWERUP_H
#include "LTexture.h"
#include "Object.h"
#include <string>


class Powerup: public Object
{
    public:
        Powerup();
        Powerup(LTexture*, float, float);
        int GetType();
        void SetScroll(float scroll);
        virtual void Render(long int&, SDL_Renderer*) = 0;
        virtual ~Powerup();

    protected:
        float scroll;

    private:
};

#endif // POWERUP_H
