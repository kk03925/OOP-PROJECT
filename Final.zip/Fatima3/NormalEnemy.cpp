#include "NormalEnemy.h"


NormalEnemy::NormalEnemy(LTexture* image,float x,float y,float worldx,float worldy) : Enemy(image,x,y,worldx,worldy)
{



}

}

NormalEnemy::~NormalEnemy()
{
    //dtor
}
