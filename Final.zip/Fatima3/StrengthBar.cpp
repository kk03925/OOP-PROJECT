#include "StrengthBar.h"

StrengthBar::StrengthBar(): BarClass()
{

}

StrengthBar::StrengthBar(LTexture* image, LTexture* health,float x, float y): BarClass(image, icon_image)
{
    this -> image = image;
    this -> icon_image = health;
    this -> x = x;
    this -> y = y;
}

void StrengthBar::Render(long int&, int strength, SDL_Renderer* gRenderer)
{
    if (strength == 3 && time > 0)
    {
        bar = {(int)x,(int)y, time*25 , 25};
        image-> RenderTexture(0, 0,gRenderer, &bar, 0, NULL, 1);
        icon_image-> RenderTexture(20*25,0, gRenderer,NULL, 0, NULL, 0.06);
        time = time -1;
    }
}

void StrengthBar::operator = (const StrengthBar& cpy)
{
    this -> image = cpy.image;
    this -> icon_image = cpy.icon_image;
    this -> x = x;
    this -> y = y;
    this -> time = cpy.time;

}


StrengthBar::~StrengthBar()
{
    //dtor
}
