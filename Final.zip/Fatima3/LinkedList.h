#pragma once

#include <fstream>
#include "Object.h"
#include "LTexture.h"
#include "Constants.h"

template <typename T>
struct Node
{
    Node<T>* prev;
    Node<T>* next;
    T data;
    ~Node<T>()
    {
        delete data;
    }
};

template <typename T>
class LinkedList
{
private:
    Node<T>* head;
    Node<T>* tail;
    int length;
    float VisibleWorldX =0;
    float VisibleWorldY = 0;
public:
    LinkedList()
    {
        cout<<"Linked List Created"<<endl;
        head=NULL;
        tail=NULL;
        length=0;
    }
    ~LinkedList()
    {
        cout<<"Linked List Destroyed";
        CleanAll();
        delete head;
        delete tail;
        head = NULL;
        tail = NULL;
    }


    void Push(T data);
    T Pop();
    bool isEmpty();
    void Draw(SDL_Renderer* buffer);
    void handleEvent(SDL_Event& e);
    void Update();
    void CleanAll();
    void Move(int);
    void AladdinTracker();
    void Render(long int& frame,SDL_Renderer* gRenderer);
    void CheckCollision();
    bool IsInsideVisibleWorld(float,float,float,float);
    void Collide(Object*,Object*);
    bool hit(Object*,Object*);
    int GetLength();
};

template <typename T>
void LinkedList<T>::Push(T data)
{

    if(head == NULL)
    {
        //if pointers are null
        Node<T>* temp = new Node<T>;    //create a new node temp
        temp->data = data;  //save data to it
        temp->next = NULL;  //set its next to null
        temp->prev = NULL;  //set its prev to null
        tail = temp;    // set head and tail as this node
        head = temp;
    }
    else
    {
        //if head not null, means not first node
        Node<T>* temp = new Node<T>;    //create new node
        temp->data = data;  //set its data
        tail->next = temp;  //set the tail's next to this node
        temp->next = NULL;  //set this node's next to NULL
        temp->prev = tail;  //set this node's prev to the tail
        tail = temp;    //set tail as this node

    }
    length++;
}

template <typename T>
T LinkedList<T>::Pop()
{

    if(!isEmpty())
    {
        //if not empty, then only pop
        if(head == tail)    //if head and tail are both equal (only one node)
        {

            T x = tail->data;   //create new template type and store data in it
            delete tail;    //delete the tail
            tail = NULL;    //mark tail NULL
            head = NULL;    //mark head NULL
            return x;   //return the stored data
        }
        else
        {
            //if not the last node
            Node<T>* temp = new Node<T>;    //create new temp node
            temp = tail;    //set temp to tail
            tail = tail->prev;  //set tail as the previous of tail
            tail->next = NULL;  //set the next of the current tail as NULL
            T x = temp->data;   //save the data in the TO-BE-REMOVED node
            return x;

        }
        length--;
    }
    else
    {
        //if empty, then return NULL
        return NULL;
    }

}

template <typename T>
void LinkedList<T>::CheckCollision()
{

    Node<T>* temp = head;  //A new pointer of type Node is created i.e pointing towards head
    while(temp!=NULL)   //This pointer iterates till the end of list
    {
        Node<T>* temp2 = temp->next;   //A second pointer is created that is pointing towards the second element in list
        while(temp2!=NULL)  //This pointer 2 also iterates over a list, this ensures every element is checked with every other element
        {
            if( hit(temp->data,temp2->data) ) //if datas arent of same type and they arent collision and they hit each other
            {
                Collide(temp->data,temp2->data);   //then call function collide and pass both datas to it (they collided exclusively)
            }
            temp2 = temp2->next;
        }
         temp=temp->next;
    }
}

template <typename T>
void LinkedList<T>::Collide(Object* o1,Object* o2)
{
        cout<<"Objects colliding"<<endl;

        if(o2->GetType()==1)
        {
            cout<<"collided with enemy"<<endl;
            o1->takeDamage(o2->GetDamageCaused());
        }
        else if (o2->GetType()==2)
        {
            cout<<"collided with weapon"<<endl;
            o1->takeDamage(o2->GetDamageCaused());
        }
        else if (o2->GetType()==3)
        {
            cout<<"collided with health powerup"<<endl;
             o1->SetHealth(1);
             o2->GetTexture()->Free();
        }
        else if (o2->GetType()==4)
        {
            cout<<"collided with quantity powerup"<<endl;
            o1->SetQuantity(1);
            o2->GetTexture()->Free();
        }
        else if (o2->GetType()==5)
        {
            cout<<"collided with strength powerup"<<endl;
            o1->SetStrength();
            o2->GetTexture()->Free();
        }
        else if (o2->GetType()==6)
        {

        }
        else if (o2->GetType()==7)
        {

        }
        else if (o2->GetType()==8)
        {

        }
        else if (o2->GetType()==9)
        {

        }
        else if (o2->GetType()==10)
        {

        }


    }



template <typename T>
bool LinkedList<T>::hit(Object* object1, Object* object2)
{
    SDL_Rect object1Rect = {object1->GetX(),object1->GetY(),object1->colRecWidth,object1->colRecHeight};
    SDL_Rect object2Rect = {object2->GetX(),object2->GetY(),object2->colRecWidth,object2->colRecHeight};

    if (SDL_HasIntersection(&object1Rect , &object2Rect))
    {
        return true;
    }

    return false;

}

template <typename T>
bool LinkedList<T>::isEmpty()
{
    return (head==NULL);    //if head is NULL, its empty
}

template <typename T>
void LinkedList<T>::Render(long int& frame,SDL_Renderer* gRenderer)
{

    Node<T>* temp;
    temp = head;    //temp is head
    while (temp!=NULL)  //while we dont reach last node
    {
        bool insideVisibleWorld = IsInsideVisibleWorld(VisibleWorldX,VisibleWorldY,temp->data->GetWorldX(),temp->data->GetWorldY());

        if(insideVisibleWorld)
        {
            temp->data->Render(frame,gRenderer); //output every data
        }
        temp = temp->next;
    }

}


template <typename T>
bool LinkedList<T>::IsInsideVisibleWorld(float visibleX,float visibleY,float objectWorldX,float objectWorldY)
{
    //  cout<<visibleX<<" Vis x"<<objectWorldX<<" obj x"<<endl;
    if(visibleX+SCREEN_WIDTH<objectWorldX || visibleX>objectWorldX+30)
    {
        return false;
    }
    return true;
}

template <typename T>
void LinkedList<T>::handleEvent(SDL_Event& e)
{

    Node<T>* temp;
    temp = head;    //temp is head
    while (temp!=NULL)  //while we dont reach last node
    {
        if (temp->data->GetType() == PLAYER )
        {
            temp->data->handleEvent(e); //output every data
            temp = temp->next;
            break;
        }
    }
}

template <typename T>

void LinkedList<T>::AladdinTracker()
{
    float WorldXOfAladin = 0;
    float WorldYOfAladin = 0;

    Node<T>* temp2;
    temp2 = head;    //temp is head
    while (temp2!=NULL)  //while we dont reach last node
    {
        if(temp2->data->GetType()==0)
        {
            //If aladin found in linked list
            WorldXOfAladin = temp2->data->GetWorldX();
            WorldYOfAladin = temp2->data->GetWorldY();
            break;
        }

        temp2 = temp2->next;
    }
    Node<T>* temp;
    temp = head;    //temp is head
    while (temp!=NULL)  //while we dont reach last node
    {
        bool insideVisibleWorld = IsInsideVisibleWorld(VisibleWorldX,VisibleWorldY,temp->data->GetWorldX(),temp->data->GetWorldY());

        if(insideVisibleWorld && (temp->data->GetType() == ENEMY ) )
        {
            temp->data->AladdinTracker(WorldXOfAladin,WorldYOfAladin); //output every data
        }
        temp = temp->next;
    }
}

template <typename T>
void LinkedList<T>::Move(int direction)
{

    if(direction==RIGHT)
    {
        VisibleWorldX+=WORLD_COORD_CHANGE_PER_CLICK;
    }
    if(direction==LEFT)
    {

        VisibleWorldX -=WORLD_COORD_CHANGE_PER_CLICK;
    }
    Node<T>* temp;
    temp = head;    //temp is head
    while (temp!=NULL && (temp->data->GetType() == ENEMY || temp->data->GetType() == PLAYER ))  //while we dont reach last node
    {
        temp->data->Move(direction); //output every data
        temp = temp->next;
    }

}



template <typename T>
int LinkedList<T>::GetLength()
{
    return length;
}

template <typename T>
void LinkedList<T>::CleanAll()
{
    Node<T>* temp = head;

    while(temp != NULL)
    {

        if(temp == head)
        {

            if(temp->data != NULL)
            {

                if(temp->data->isAlive() == false)
                {


                    head = head->next;

                    if(head!=NULL)
                    {

                        head->prev = NULL;

                    }

                    delete temp;

                    temp = head;


                }
                else
                {
                    temp = temp->next;
                }
            }
            else
            {
                break;
            }
        }
        else if(temp == tail)
        {

            if(temp->data!=NULL)
            {
                if(temp->data->isAlive() == false)
                {

                    tail = tail->prev;
                    tail->next = NULL;

                    delete temp;

                    temp = NULL;
                }
                else
                {
                    temp = temp->next;
                }
            }
        }
        else
        {

            if(temp->data->isAlive() == false)
            {

                Node<T>* keeper = temp;
                temp->prev->next = temp->next;
                temp->next->prev = temp->prev;
                temp = temp->next;
                delete keeper;
            }
            else
            {
                temp = temp->next;
            }
        }
    }
}
