#include "PowerupFactory.h"
#include "HealthPowerup.h"
#include "QuantityPowerup.h"
#include "StrengthPowerup.h"

PowerupFactory::PowerupFactory()
{
    //ctor
}

Powerup* PowerupFactory::GetPowerup(LTexture* image, float x, float y, int type)  // creates the relevant power and returns it
{
    if(type == 0)
    {
        powerup = new HealthPowerup(image, x, y);
    }

    if(type == 1)
    {
        powerup = new QuantityPowerup(image, x, y);
    }

    if(type == 2)
    {
        powerup = new StrengthPowerup(image,x,y);
    }
    return powerup;
}

PowerupFactory::~PowerupFactory()
{
    //dtor
}
