#include "GameScreen.h"

GameScreen::GameScreen(LTexture* image_one, LTexture* image_two, LTexture* image_three, LTexture* font_sprite):
    Screen(bg_image, font_sprite)
{
    this->bg_image = image_one;
    font_sprite = NULL;
    this-> image_two = image_two;
    this->image_three = image_three;
}
void GameScreen::Render(float& scroll_one, float& scroll_two, float& scroll_three, SDL_Renderer* gRenderer)
{
   // SDL_Rect rect = {0, 0, 1366, 700};
    bg_image -> RenderTexture( scroll_one, 0, gRenderer, NULL, 0, NULL, 1.25);
    image_two -> RenderTexture( scroll_two, 132, gRenderer, NULL, 0, NULL, 1);
    image_three -> RenderTexture( scroll_three, 130, gRenderer, NULL, 0, NULL, 1);
}

GameScreen::~GameScreen()
{
    cout<< "Game Screen no more."<<endl;
}
