#include "Weapons.h"

Weapons::Weapons()
{
    //ctor
}

Weapons::~Weapons()
{
    //dtor
}
