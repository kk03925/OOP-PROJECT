#ifndef BARRELLS_H
#define BARRELLS_H
#include"LTexture.h"
#include "Item.h"


class Barrells : Item
{
    public:
        Barrells(LTexture*,float,float,float,float);
        ~Barrells();


    protected:

    private:
        LTexture *pic;
        SDL_Rect gThrowingRightSpriteClips[10];
        SDL_Rect gThrowingLeftSpriteClips[10];
};

#endif // BARRELLS_H
