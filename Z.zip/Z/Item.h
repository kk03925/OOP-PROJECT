#ifndef ITEM_H
#define ITEM_H
#include "Object.h"
#include "LTexture.h"


class Item : public Object
{
    public:
        Item(LTexture*,float,float,float,float);
        virtual ~Item();

    protected:
        LTexture* image;
};

#endif // ITEM_H
