#ifndef CLEVERENEMY_H
#define CLEVERENEMY_H
#include "Enemy.h"
#include "Player.h"
#include "LTexture.h"


class CleverEnemy : public Enemy
{
    public:
        CleverEnemy(LTexture*,float,float,float,float);
        void Render(long int& frame, SDL_Renderer* gRenderer);
        void Move(int);
        void Attack(float);
        void AladdinTracker(float,float);
        ~CleverEnemy();


    protected:


    private:
        SDL_Rect gWalkingLeftSpriteClips[8];
        SDL_Rect gWalkingRightSpriteClips[8];
        bool ifThrowing;





};




#endif // CLEVERENEMY_H
