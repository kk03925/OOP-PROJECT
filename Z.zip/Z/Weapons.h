#ifndef WEAPONS_H
#define WEAPONS_H



class Weapons
{
    public:
        Weapons();
        ~Weapons();

    protected:

    private:

};

#endif // WEAPONS_H
