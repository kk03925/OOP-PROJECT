#include "Barrells.h"
#include "LTexture.h"

Barrells::Barrells(LTexture* pic,float x,float y,float worldx,float worldy) : Item(image,x,y,worldx,worldy)
{
    this-> pic = pic;
    gThrowingRightSpriteClips [0].x = 2;
    gThrowingRightSpriteClips [0].y = 495;
    gThrowingRightSpriteClips [0].w = 110;
    gThrowingRightSpriteClips [0].h = 216;

    gThrowingRightSpriteClips [1].x = 112;
    gThrowingRightSpriteClips [1].y = 495;
    gThrowingRightSpriteClips [1].w = 168;
    gThrowingRightSpriteClips [1].h = 216;

    gThrowingRightSpriteClips [2].x = 280;
    gThrowingRightSpriteClips [2].y = 495;
    gThrowingRightSpriteClips [2].w = 86;
    gThrowingRightSpriteClips [2].h = 216;

    gThrowingRightSpriteClips [3].x = 366;
    gThrowingRightSpriteClips [3].y = 495;
    gThrowingRightSpriteClips [3].w = 78;
    gThrowingRightSpriteClips [3].h = 216;

    gThrowingRightSpriteClips [4].x = 444;
    gThrowingRightSpriteClips [4].y = 495;
    gThrowingRightSpriteClips [4].w = 80;
    gThrowingRightSpriteClips [4].h = 216;

    gThrowingRightSpriteClips [5].x = 524;
    gThrowingRightSpriteClips [5].y = 495;
    gThrowingRightSpriteClips [5].w = 79;
    gThrowingRightSpriteClips [5].h = 216;

    gThrowingRightSpriteClips [6].x = 603;
    gThrowingRightSpriteClips [6].y = 495;
    gThrowingRightSpriteClips [6].w = 84;
    gThrowingRightSpriteClips [6].h = 216;

    gThrowingRightSpriteClips [7].x = 687;
    gThrowingRightSpriteClips [7].y = 495;
    gThrowingRightSpriteClips [7].w = 80;
    gThrowingRightSpriteClips [7].h = 216;

    gThrowingRightSpriteClips [8].x = 767;
    gThrowingRightSpriteClips [8].y = 495;
    gThrowingRightSpriteClips [8].w = 76;
    gThrowingRightSpriteClips [8].h = 216;

    gThrowingRightSpriteClips [9].x = 843;
    gThrowingRightSpriteClips [9].y = 495;
    gThrowingRightSpriteClips [9].w = 79;
    gThrowingRightSpriteClips [9].h = 216;

    gThrowingLeftSpriteClips [0].x = 1995;
    gThrowingLeftSpriteClips [0].y = 488;
    gThrowingLeftSpriteClips [0].w = 111;
    gThrowingLeftSpriteClips [0].h = 216;

    gThrowingLeftSpriteClips [1].x = 2106;
    gThrowingLeftSpriteClips [1].y = 488;
    gThrowingLeftSpriteClips [1].w = 170;
    gThrowingLeftSpriteClips [1].h = 216;

    gThrowingLeftSpriteClips [2].x = 2276;
    gThrowingLeftSpriteClips [2].y = 488;
    gThrowingLeftSpriteClips [2].w = 82;
    gThrowingLeftSpriteClips [2].h = 216;

    gThrowingLeftSpriteClips [3].x = 2358;
    gThrowingLeftSpriteClips [3].y = 488;
    gThrowingLeftSpriteClips [3].w = 77;
    gThrowingLeftSpriteClips [3].h = 216;

    gThrowingLeftSpriteClips [4].x = 2435;
    gThrowingLeftSpriteClips [4].y = 488;
    gThrowingLeftSpriteClips [4].w = 81;
    gThrowingLeftSpriteClips [4].h = 216;

    gThrowingLeftSpriteClips [5].x = 2516;
    gThrowingLeftSpriteClips [5].y = 488;
    gThrowingLeftSpriteClips [5].w = 80;
    gThrowingLeftSpriteClips [5].h = 216;

    gThrowingLeftSpriteClips [6].x = 2596;
    gThrowingLeftSpriteClips [6].y = 488;
    gThrowingLeftSpriteClips [6].w = 82;
    gThrowingLeftSpriteClips [6].h = 216;

    gThrowingLeftSpriteClips [7].x = 2678;
    gThrowingLeftSpriteClips [7].y = 488;
    gThrowingLeftSpriteClips [7].w = 80;
    gThrowingLeftSpriteClips [7].h = 216;

    gThrowingLeftSpriteClips [8].x = 2758;
    gThrowingLeftSpriteClips [8].y = 488;
    gThrowingLeftSpriteClips [8].w = 78;
    gThrowingLeftSpriteClips [8].h = 216;

    gThrowingLeftSpriteClips [9].x = 2836;
    gThrowingLeftSpriteClips [9].y = 488;
    gThrowingLeftSpriteClips [9].w = 79;
    gThrowingLeftSpriteClips [9].h = 216;

}

Barrells::~Barrells()
{
    //dtor
}
