#ifndef PLAYER_H
#define PLAYER_H
#include "LTexture.h"
#include "Object.h"
#include "Constants.h"
class Player : public Object
{
    public:
        Player(LTexture*,float,float,float,float);
        void Render(long int& frame, SDL_Renderer* gRenderer);
        virtual ~Player();
        int direction;
        int AnimationFrame;
        bool movement;
        void Draw(SDL_Renderer*);
        void Move(int);
        void AladdinTracker(float,float);
        void handleEvent(SDL_Event& e);


    private:

        static const int PlayerVelocity = 2;

        SDL_Rect gWalkingRightSpriteClips[ 12 ];
        SDL_Rect gWalkingLeftSpriteClips[ 12 ];
        SDL_Rect gThrowingLeftSpriteClips[ 4 ];
        SDL_Rect gThrowingRightSpriteClips[ 4 ];
        SDL_Rect gDuckingSpriteClips[ 1 ];
        SDL_Rect gStandingSpriteClips [ 2];
};

#endif // PLAYER_H
