#include <stdio.h>
#include <string>
#include "string.h"
#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
#include "LTexture.h"
#include "Screen.h"
#include "SplashScreen.h"
#include "MenuScreen.h"
#include "GameScreen.h"
#include "Player.h"
#include "Enemy.h"
#include "CleverEnemy.h"
#include "LinkedList.h"
#include "LinkedList.cpp"
#include "Constants.h"
using namespace std;



//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

void close();

void SetAlpha();

//Loads individual image as texture

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;
//LTexture gDotTexture;
LTexture splash_texture;
LTexture menu_texture;
LTexture game_texture_one;
LTexture game_texture_two;
LTexture game_texture_three;
LTexture Aladdin;
LTexture cenemy;

LTexture font_texture;
LTexture gExcerpt;

//Alpha Modulation component
float opaque = 255; //one component is set to full opaque
float trasparency = 0; //other is full transparent


bool init()
{
	//Initialization mouseClicked
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( gWindow == NULL )
        {
            printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Create renderer for window
            gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
            else
            {
                //Initialize renderer color
                SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

                //Initialize PNG loading
                int imgFlags = IMG_INIT_PNG;
                if( !( IMG_Init( imgFlags ) & imgFlags ) )
                {
                    printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
                    success = false;
                }
            }
        }

    }
	return success;
}

bool loadMedia()
{
	///Loading success flag
	bool success = true;

	if( !splash_texture.LoadFromFile( "splash_screen.png", gRenderer  ) )
	{
		printf( "Failed to load splash sheet texture!\n" );
		success = false;
	}
    else
    {
        ///Set standard alpha blending
        splash_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !menu_texture.LoadFromFile( "menu_screen.png", gRenderer  ) )
	{
		printf( "Failed to load splash sheet texture!\n" );
		success = false;
	}
    else
    {
        ///Set standard alpha blending
        menu_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !game_texture_one.LoadFromFile( "sky_bg.png", gRenderer  ) )
	{
		printf( "Failed to load game sheet texture!\n" );
		success = false;
	}
    else
    {
        ///Set standard alpha blending
       game_texture_one.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !game_texture_two.LoadFromFile( "building_bg.png", gRenderer  ) )
	{
		printf( "Failed to load game sheet texture!\n" );
		success = false;
	}
    else
    {
        ///Set standard alpha blending
       game_texture_two.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !game_texture_three.LoadFromFile( "Bricks.png", gRenderer  ) )
	{
		printf( "Failed to load game sheet texture!\n" );
		success = false;
	}
    else
    {
        ///Set standard alpha blending
        game_texture_three.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !Aladdin.LoadFromFile( "Aladdin.png", gRenderer  ) )
	{
		printf( "Failed to load game sheet texture!\n" );
		success = false;
	}
    else
    {
        ///Set standard alpha blending
        Aladdin.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
    if( !cenemy.LoadFromFile( "F2.png", gRenderer  ) )
	{
		printf( "Failed to load game sheet texture!\n" );
		success = false;
	}
    else
    {
        ///Set standard alpha blending
        cenemy.SetBlendMode( SDL_BLENDMODE_BLEND );
    }


	//Nothing to load
	return success;
}

void close()
{
	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;
	splash_texture.Free();
	menu_texture.Free();
	game_texture_one.Free();
	game_texture_two.Free();
	game_texture_three.Free();
	Aladdin.Free();
	cenemy.Free();

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}


int main( int argc, char* args[] )
{
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
	    if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{

            long int frame = 0;
            int RunningFrame = 0;
            bool is_splash = true;
            bool is_menu = false;
            bool is_game = false;
            SplashScreen splash(&splash_texture, &font_texture);
            MenuScreen menu(&menu_texture, &font_texture);
            GameScreen game_screen(&game_texture_one, &game_texture_two, &game_texture_three, &font_texture);
            //Player player(&Aladdin,50,50,50,50);
//            CleverEnemy enemy(&cenemy);

			bool quit = false;  //Main loop controller

			SDL_Event e;        //Event handler that takes care of all events

			//The background scrolling offset
            float scroll_one = 0;
            float scroll_two = 0;
            float scroll_three = 0;

			//While application is running
            LinkedList<Object*> * ll = new LinkedList<Object*>();


            //Push aladin to linkedlist
            Object* aladin = new Player(&Aladdin,30,510,50,450);
            ll->Push(aladin);

            //push enemy to linked lsit
            Object* enemy1 = new CleverEnemy(&cenemy,SCREEN_WIDTH-50,450,1420,450);
          //  ll->Push(enemy1);

            //Push another enemy
             Object* enemy2 = new CleverEnemy(&cenemy,SCREEN_WIDTH-50,450,1590,450);
            ll->Push(enemy2);

			while( !quit )
			{
                while (SDL_PollEvent(&e))
                {
                if( e.type == SDL_QUIT ) quit = true;
                ll->handleEvent(e);
                }
                //Clear screen
				SDL_SetRenderDrawColor( gRenderer,  0, 0, 0, 0 );
				SDL_RenderClear( gRenderer );

                if(is_splash)       ///checks if Splash screen is running
                {
                    splash_texture.SetAlpha(opaque);     ///Splash Screen fades out with a decreasing
                    splash.Render(frame, gRenderer);       ///Rendering Splash Screen
                    if(opaque == 0)
                    {
                        is_splash = false;    ///indicates the end of splash screen run
                        is_menu = true;
                        opaque = 255; //reset
                        trasparency = 0; //reset
                    }
                }

                if (is_menu)
                {
                    menu_texture.SetAlpha(255);
                    menu.Render(frame, gRenderer);
                    is_menu = false;
                    is_game = true;

                }


                if (is_game) //checks is game is running
                {
                    game_texture_one.SetAlpha(255);
                    game_texture_two.SetAlpha(255);
                    game_texture_three.SetAlpha(255);
                    game_screen.Render(scroll_one, scroll_two, scroll_three, gRenderer);

                    ll->Render(frame,gRenderer);
                    ll->AutoUpdate();
                    ll->CheckCollision();
                    if (e.type == SDL_KEYDOWN)
                    {

                        if (e.key.keysym.sym==SDLK_LEFT)
                        {

                         //   player.direction=1;
                         //   player.RenderMovement(gRenderer);
                            scroll_one= scroll_one + 0.1;
                            scroll_two = scroll_two + 0.2;
                            scroll_three = scroll_three + 0.4;

                            ll->Move(LEFT);

                        }

                        else if (e.key.keysym.sym==SDLK_RIGHT)
                        {

//                            player.direction=0;
                            scroll_one= scroll_one - 0.1;
                            scroll_two = scroll_two - 0.3;
                            scroll_three = scroll_three - 0.4;
                         //   player.RenderMovement(gRenderer);
                         //   enemy.RenderMovement(gRenderer);
                            ll->Move(RIGHT);
                        }

                    }
                    if (e.key.keysym.sym == SDL_KEYUP)
                    {
//                        player.RenderMovement(gRenderer);
                    }
                    //player.RenderStatic(gRenderer);

				    //Scroll background


                    if( scroll_one < -game_texture_one.width )
                    {
                        scroll_one = 0;
                    }
                    if( scroll_three < -game_texture_three.width )
                    {
                        scroll_three = 0;
                    }


                    //Render background

                    float new_scroll_one = scroll_one + game_texture_one.width;
                    float new_scroll_two = scroll_two + game_texture_two.width;
                    float new_scroll_three = scroll_three + game_texture_three.width;

                    game_screen.Render(new_scroll_one,new_scroll_two, new_scroll_three, gRenderer );


                    //Render objects
               //     dot.Render(gRenderer);
                }
                SetAlpha(); //to decrement opaqueness and increment trasparency
                frame++;


                if ((int)frame % 50 == 0)
                {
                    frame = 0;
                }
				//Update screen
				SDL_RenderPresent( gRenderer );
			}
		}
	}
	//Free resources and close SDL
	close();

	return 0;
}

void SetAlpha()
{
    ///Cap if below 0
    if( opaque - 3 < 0 )
    {
        opaque = 0;
    }
    ///Decrement otherwise
    else
    {
        opaque -= 2;
    }
    ///Cap if above 255
    if( trasparency+ 3 > 255 )
    {
        trasparency=255;
    }
    ///Increment otherwise
    else
    {
        trasparency += 2;
    }
}
