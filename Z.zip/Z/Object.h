#ifndef OBJECT_H
#define OBJECT_H
#include "LTexture.h"

enum {LEFT,RIGHT};
enum {PLAYER,ENEMY,WEAPON,TRAP,POWERUP};
class Object
{
public:


    Object() {}
    virtual ~Object() {}

    Object(LTexture* image,float x, float y,float worldX,float worldY)
    {
        this->x = x;
        this->y = y;
        this->WorldX = worldX;
        this->WorldY = worldY;
    }
    virtual void handleEvent( SDL_Event& e )
    {

    }
    virtual void AutoUpdate(float,float)
    {

    }


    virtual int GetType()
    {
        return type;
    }
    virtual void setAlive(bool alive)
    {
        this->alive = alive;
    }
    virtual bool isAlive()
    {
        return alive;
    }
/*
    virtual void Draw(SDL_Renderer*,float,float)
    {

    }
*/
    virtual void Render(long int& frame,SDL_Renderer* gRenderer) = 0;

    virtual float GetX()
    {
        return x;
    }
    virtual float GetY()
    {
        return y;
    }
    virtual float GetPosX()
    {
        return x;
    }
    virtual float GetPosY()
    {
        return y;
    }
    virtual float GetWorldX()
    {

        return WorldX;
    }
    virtual float GetWorldY()
    {
        return WorldY;
    }
    virtual float GetFrameWidth()
    {
        return colRecWidth;
    }
    virtual float GetFrameHeight()
    {
        return colRecHeight;
    }
    virtual void Move(int)
    {


    }
    virtual float GetDamageCaused()
    {
        return damageCaused;
    }
    virtual void takeDamage(float damage)
    {
        cout<<damage<<endl;
        health = health - damage;
        if(health<=0)
            alive = false;
    }
protected:

    LTexture* image;

    int type;

    float x;
    float y;

    float WorldX;
    float WorldY;

    float colRecWidth;
    float colRecHeight;

    float health;
    float damageCaused;
    bool alive;

    int AnimationFrame = 0;

    int mVelX = 0;

};

#endif // OBJECT_H
