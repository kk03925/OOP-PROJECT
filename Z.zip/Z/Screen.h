#ifndef SCREEN_H
#define SCREEN_H
#include "LTexture.h"

class Screen
{
    public:
        Screen(LTexture*,LTexture*);
        virtual ~Screen();

    protected:
        LTexture* bg_image;    //background image of the screen
        LTexture* font_sprite;  //image consisting of fonts, and buttons

    private:

};

#endif // SCREEN_H
