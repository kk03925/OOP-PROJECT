#include "MenuScreen.h"

MenuScreen::MenuScreen(LTexture* bg_image, LTexture* font_sprite) : Screen(bg_image,font_sprite)
{
    this->bg_image = bg_image;
    this->font_sprite = font_sprite;
}

void MenuScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    SDL_Rect rect = {0, 0, 1366, 700};
    bg_image->RenderTexture( 0, 0,gRenderer, &rect, 0, NULL, 1);
   // buttonScreen->RenderTexture(width/2 - 250,height/2 - 120,gRenderer,NULL);
/*    for(int i=0; i<ButtonCount; i++)
    {
        buttons[i].Render(gRenderer);
    } */
}

MenuScreen::~MenuScreen()
{
    cout<<"Menu Screen Destroyed"<<endl;
}
