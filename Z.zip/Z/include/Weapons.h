#ifndef WEAPONS_H
#define WEAPONS_H


class Weapons
{
    public:
        Weapons();
        virtual ~Weapons();

    protected:

    private:
};

#endif // WEAPONS_H
