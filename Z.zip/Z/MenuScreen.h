#ifndef MENUSCREEN_H
#define MENUSCREEN_H
#include "Screen.h"
#include "LTexture.h"

class MenuScreen: public Screen
{
    public:
        MenuScreen(LTexture*,LTexture*);
        virtual ~MenuScreen();
        void Render(long int& frame, SDL_Renderer*);

    private:
        LTexture* buttonScreen; //the small screen over which buttons are drawn
        LTexture* menu_screen;

};

#endif // MENUSCREEN_H
