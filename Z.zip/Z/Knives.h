#ifndef KNIVES_H
#define KNIVES_H
#include "Item.h"
#include "LTexture.h"


class Knives : public Item
{
    public:
        Knives(LTexture*,float,float,float,float);
        virtual ~Knives();

    protected:

    private:
        LTexture* pic;
        SDL_Rect gRightKnifeSpriteClips[8];
        SDL_Rect gLeftKnifeSpriteClips[8];
};

#endif // KNIVES_H
