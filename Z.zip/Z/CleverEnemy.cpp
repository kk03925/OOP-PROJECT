#include "CleverEnemy.h"
#include "Player.h"
#include "math.h"

CleverEnemy::CleverEnemy(LTexture* image,float x,float y,float worldx,float worldy) : Enemy(image,x,y,worldx,worldy)
{
    x=x;
    y=y;
    this->image = image;
    type=1;
    damageCaused=100;
    colRecWidth = 94;
    colRecHeight = 140;
    direction = 1;
    AnimationFrame = 0;
    ifThrowing= false;


    gWalkingRightSpriteClips [0].x = 1216;
    gWalkingRightSpriteClips [0].y = 1845;
    gWalkingRightSpriteClips [0].w = 92;
    gWalkingRightSpriteClips [0].h = 140;

    gWalkingRightSpriteClips [1].x = 1308;
    gWalkingRightSpriteClips [1].y = 1845;
    gWalkingRightSpriteClips [1].w = 96;
    gWalkingRightSpriteClips [1].h = 140;

    gWalkingRightSpriteClips [2].x = 1404;
    gWalkingRightSpriteClips [2].y = 1845;
    gWalkingRightSpriteClips [2].w = 100;
    gWalkingRightSpriteClips [2].h = 140;

    gWalkingRightSpriteClips [3].x = 1504;
    gWalkingRightSpriteClips [3].y = 1845;
    gWalkingRightSpriteClips [3].w = 105;
    gWalkingRightSpriteClips [3].h = 140;

    gWalkingRightSpriteClips [4].x = 1609;
    gWalkingRightSpriteClips [4].y = 1845;
    gWalkingRightSpriteClips [4].w = 91;
    gWalkingRightSpriteClips [4].h = 140;

    gWalkingRightSpriteClips [5].x = 1700;
    gWalkingRightSpriteClips [5].y = 1845;
    gWalkingRightSpriteClips [5].w = 87;
    gWalkingRightSpriteClips [5].h = 140;

    gWalkingRightSpriteClips [6].x = 1787;
    gWalkingRightSpriteClips [6].y = 1845;
    gWalkingRightSpriteClips [6].w = 98;
    gWalkingRightSpriteClips [6].h = 140;

    gWalkingRightSpriteClips [7].x = 1885;
    gWalkingRightSpriteClips [7].y = 1845;
    gWalkingRightSpriteClips [7].w = 93;
    gWalkingRightSpriteClips [7].h = 140;

    gWalkingLeftSpriteClips [0].x = 850;
    gWalkingLeftSpriteClips [0].y = 1818;
    gWalkingLeftSpriteClips [0].w = 94;
    gWalkingLeftSpriteClips [0].h = 140;

    gWalkingLeftSpriteClips [1].x = 756;
    gWalkingLeftSpriteClips [1].y = 1800;
    gWalkingLeftSpriteClips [1].w = 98;
    gWalkingLeftSpriteClips [1].h = 140;

    gWalkingLeftSpriteClips [2].x = 658;
    gWalkingLeftSpriteClips [2].y = 1800;
    gWalkingLeftSpriteClips [2].w = 96;
    gWalkingLeftSpriteClips [2].h = 140;

    gWalkingLeftSpriteClips [3].x = 562;
    gWalkingLeftSpriteClips [3].y = 1800;
    gWalkingLeftSpriteClips [3].w = 105;
    gWalkingLeftSpriteClips [3].h = 140;

    gWalkingLeftSpriteClips [4].x = 457;
    gWalkingLeftSpriteClips [4].y = 1800;
    gWalkingLeftSpriteClips [4].w = 92;
    gWalkingLeftSpriteClips [4].h = 140;

    gWalkingLeftSpriteClips [5].x = 365;
    gWalkingLeftSpriteClips [5].y = 1800;
    gWalkingLeftSpriteClips [5].w = 89;
    gWalkingLeftSpriteClips [5].h = 140;

    gWalkingLeftSpriteClips [6].x = 276;
    gWalkingLeftSpriteClips [6].y = 1800;
    gWalkingLeftSpriteClips [6].w = 97;
    gWalkingLeftSpriteClips [6].h = 140;

    gWalkingLeftSpriteClips [7].x = 179;
    gWalkingLeftSpriteClips [7].y = 1800;
    gWalkingLeftSpriteClips [7].w = 91;
    gWalkingLeftSpriteClips [7].h = 140;


    alive = true;

}

void CleverEnemy::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (frame % 30 == 0)
    {
        AnimationFrame++; //to control speed of the clips rendering of the ghosts
    }

    if (alive)
    {
        if (ifThrowing == false)
        {
            if (direction==0)
            {
                //cout<<"I am right"<<endl;
                image->RenderTexture(x,y, gRenderer,&gWalkingRightSpriteClips[AnimationFrame % 8],0, NULL, 1);
            }
            else if (direction == 1)
            {
                //cout<<"because you left"<<endl;
                image->RenderTexture(x,y, gRenderer,&gWalkingLeftSpriteClips[AnimationFrame % 8],0, NULL, 1);
            }
            else
            {
                //image->
            }

        }
    }

    if (AnimationFrame >= 8)
    {
        AnimationFrame = 0;
    }
}

/*
void CleverEnemy::Draw(SDL_Renderer* gRenderer,float VisibleWorldX,float VisibleWorldY)
{
    if (alive)
    {

      //  image->RenderTexture(WorldX-VisibleWorldX,y, gRenderer,&gStandingStillSpriteClips[0],0, NULL, 1);
    }
}
*/
void CleverEnemy::Attack(float)
{

}

CleverEnemy::~CleverEnemy()
{
    //dtor
}

void CleverEnemy::Move(int direction)
{


}

void CleverEnemy::AladdinTracker(float AladdinX,float AladdinY)
{
    if (AladdinX<WorldX)
    { if (WorldX - AladdinX <= 100)
        {
            ifThrowing = true;
        }
        else
        {
            direction = 1;
            WorldX -=1;
            x -=1;
        }
    }
    else if (AladdinX>WorldX)
    {
        direction = 0;
        WorldX+=1;
        x+=1;
    }
}
