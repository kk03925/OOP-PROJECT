#include "Screen.h"

Screen::Screen(LTexture* bg_image,LTexture* font_sprite)
{
    this->font_sprite = font_sprite;
}

Screen::~Screen()
{
    //dtor
}
