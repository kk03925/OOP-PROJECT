#pragma once

#include <fstream>
#include "Object.h"
#include "LTexture.h"
#include "Constants.h"
template <typename T>
struct Node
{
    Node<T>* prev;
    Node<T>* next;
    T data;
    ~Node<T>()
    {
        delete data;
    }
};

template <typename T>
class LinkedList
{
private:
    Node<T>* head;
    Node<T>* tail;
    int length;
    float VisibleWorldX =0;
    float VisibleWorldY = 0;
public:
    LinkedList()
    {
        cout<<"Linked List Created"<<endl;
        head=NULL;
        tail=NULL;
        length=0;
    }
    ~LinkedList()
    {
        cout<<"Linked List Destroyed";
        CleanAll();
        delete head;
        delete tail;
        head = NULL;
        tail = NULL;
    }


    void Push(T data);
    T Pop();
    bool isEmpty();
    void Draw(SDL_Renderer* buffer);
    void handleEvent(SDL_Event& e);
    void Update();
    void CleanAll();
    void Move(int);
    void AladdinTracker();
    void Render(long int& frame,SDL_Renderer* gRenderer);
    void CheckCollision();
    bool IsInsideVisibleWorld(float,float,float,float);
    void Collide(Object*,Object*);
    bool hit(Object*,Object*);
    int GetLength();
};
