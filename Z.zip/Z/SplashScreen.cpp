#include "SplashScreen.h"
#include "Screen.h"

using namespace std;

SplashScreen::SplashScreen(LTexture* bg_image, LTexture* fontSprite) : Screen(bg_image,fontSprite)
{
    this->bg_image = bg_image;
    fontSprite = NULL;
}

void SplashScreen::Render( long int & frame,SDL_Renderer* gRenderer)
{
     SDL_Rect rect = {0, 0, 1366, 700};
     bg_image -> RenderTexture( 0, 0,gRenderer, &rect, 0, NULL, 1 );
}

SplashScreen::~SplashScreen()
{
    cout<<"Splash Screen no more"<<endl;
}
