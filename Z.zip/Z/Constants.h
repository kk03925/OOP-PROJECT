#pragma once
const int SCREEN_WIDTH = 1366;
const int SCREEN_HEIGHT = 700;
const float WORLD_COORD_CHANGE_PER_CLICK = 1;
