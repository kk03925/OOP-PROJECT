#include "Knives.h"


Knives::Knives(LTexture* pic,float x,float y,float worldx,float worldy) : Item(image,x,y,worldx,worldy)
{
    this->pic = pic;

    gRightKnifeSpriteClips [0].x = 232;
    gRightKnifeSpriteClips [0].y = 1674;
    gRightKnifeSpriteClips [0].w = 117;
    gRightKnifeSpriteClips [0].h = 119;

    gRightKnifeSpriteClips [1].x = 349;
    gRightKnifeSpriteClips [1].y = 1674;
    gRightKnifeSpriteClips [1].w = 52;
    gRightKnifeSpriteClips [1].h = 119;

    gRightKnifeSpriteClips [2].x = 401;
    gRightKnifeSpriteClips [2].y = 1674;
    gRightKnifeSpriteClips [2].w = 81;
    gRightKnifeSpriteClips [2].h = 119;

    gRightKnifeSpriteClips [3].x = 482;
    gRightKnifeSpriteClips [3].y = 1674;
    gRightKnifeSpriteClips [3].w = 45;
    gRightKnifeSpriteClips [3].h = 119;

    gRightKnifeSpriteClips [4].x = 527;
    gRightKnifeSpriteClips [4].y = 1674;
    gRightKnifeSpriteClips [4].w = 79;
    gRightKnifeSpriteClips [4].h = 119;

    gRightKnifeSpriteClips [5].x = 606;
    gRightKnifeSpriteClips [5].y = 1674;
    gRightKnifeSpriteClips [5].w = 81;
    gRightKnifeSpriteClips [5].h = 119;

    gRightKnifeSpriteClips [6].x = 687;
    gRightKnifeSpriteClips [6].y = 1674;
    gRightKnifeSpriteClips [6].w = 71;
    gRightKnifeSpriteClips [6].h = 119;

    gRightKnifeSpriteClips [7].x = 747;
    gRightKnifeSpriteClips [7].y = 1674;
    gRightKnifeSpriteClips [7].w = 60;
    gRightKnifeSpriteClips [7].h = 119;

    gLeftKnifeSpriteClips [0].x = 1834;
    gLeftKnifeSpriteClips [0].y = 1717;
    gLeftKnifeSpriteClips [0].w = 113;
    gLeftKnifeSpriteClips [0].h = 121;

    gLeftKnifeSpriteClips [1].x = 1721;
    gLeftKnifeSpriteClips [1].y = 1717;
    gLeftKnifeSpriteClips [1].w = 56;
    gLeftKnifeSpriteClips [1].h = 121;

    gLeftKnifeSpriteClips [2].x = 1665;
    gLeftKnifeSpriteClips [2].y = 1717;
    gLeftKnifeSpriteClips [2].w = 80;
    gLeftKnifeSpriteClips [2].h = 121;

    gLeftKnifeSpriteClips [3].x = 1585;
    gLeftKnifeSpriteClips [3].y = 1717;
    gLeftKnifeSpriteClips [3].w = 43;
    gLeftKnifeSpriteClips [3].h = 121;

    gLeftKnifeSpriteClips [4].x = 1542;
    gLeftKnifeSpriteClips [4].y = 1717;
    gLeftKnifeSpriteClips [4].w = 83;
    gLeftKnifeSpriteClips [4].h = 121;

    gLeftKnifeSpriteClips [5].x = 1459;
    gLeftKnifeSpriteClips [5].y = 1717;
    gLeftKnifeSpriteClips [5].w = 70;
    gLeftKnifeSpriteClips [5].h = 121;

    gLeftKnifeSpriteClips [6].x = 1389;
    gLeftKnifeSpriteClips [6].y = 1717;
    gLeftKnifeSpriteClips [6].w = 76;
    gLeftKnifeSpriteClips [6].h = 121;

    gLeftKnifeSpriteClips [7].x = 1313;
    gLeftKnifeSpriteClips [7].y = 1717;
    gLeftKnifeSpriteClips [7].w = 64;
    gLeftKnifeSpriteClips [7].h = 121;
}

Knives::~Knives()
{
    //dtor
}
