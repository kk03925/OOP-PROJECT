#include "Button.h"

Button::Button(LTexture* image)
{
     state = Normal;
     this-> button_image = image;
   // this->text=text;

    spriteClips[Normal].x = 0;
    spriteClips[Normal].y = 95;
    spriteClips[Normal].w = 190;
    spriteClips[Normal].h = 46;
    spriteClips[Hover].x = 0;
    spriteClips[Hover].y = 45;
    spriteClips[Hover].w = 190;
    spriteClips[Hover].h = 48;
    spriteClips[Clicked].x = 191;
    spriteClips[Clicked].y = 0;
    spriteClips[Clicked].w = 190;
    spriteClips[Clicked].h = 48;
    width = spriteClips[Normal].w;
    height = spriteClips[Normal].h;

}

Button::~Button()
{
    //dtor
}
