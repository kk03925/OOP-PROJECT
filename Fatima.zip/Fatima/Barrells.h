#ifndef BARRELLS_H
#define BARRELLS_H
#include"LTexture.h"
#include "Weapons.h"


class Barrells : public Object
{
    public:
        Barrells(LTexture*,float,float,float,float);
        ~Barrells();


    protected:

    private:
        LTexture *pic;
        SDL_Rect gThrowingRightSpriteClips[10];
        SDL_Rect gThrowingLeftSpriteClips[10];
};

#endif // BARRELLS_H
