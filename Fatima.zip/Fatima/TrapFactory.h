#ifndef TRAPFACTORY_H
#define TRAPFACTORY_H
#include "Traps.h"


class TrapFactory
{
    public:
        TrapFactory();
        Traps* GetTrap(LTexture*, float, float, int);
        virtual ~TrapFactory();

    protected:

    private:
        Traps* trap;
};

#endif // TRAPFACTORY_H
