#ifndef POWERUPFACTORY_H
#define POWERUPFACTORY_H
#include "Powerup.h"

class PowerupFactory
{
    public:
        PowerupFactory();
        Powerup* GetPowerup(LTexture*, float, float, int);
        virtual ~PowerupFactory();

    protected:

    private:
        Powerup* powerup;
};

#endif // POWERUPFACTORY_H
