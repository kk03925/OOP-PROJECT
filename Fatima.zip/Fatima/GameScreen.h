#ifndef GAMESCREEN_H
#define GAMESCREEN_H
#include "LTexture.h"
#include "MenuScreen.h"
#include "Button.h"


class GameScreen: public MenuScreen
{
    public:
        GameScreen(LTexture*, LTexture*, LTexture*, LTexture*, LTexture*);
        void Render( long int&, float&, float&, float&, SDL_Renderer* gRenderer) ;
        virtual ~GameScreen();

    protected:

    private:
        LTexture* image_two;  //image consisting of fonts, and buttons
        LTexture* image_three; //front image with poles to create parallax effect
};

#endif // GAMESCREEN_H
