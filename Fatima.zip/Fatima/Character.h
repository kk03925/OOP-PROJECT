#ifndef CHARACTER_H
#define CHARACTER_H
#include "LTexture.h"
#include "Object.h"

class Character : public Object
{
    public:
        Character();
        Character(LTexture* image, float x, float y, int);
        void Render(long int&, SDL_Renderer* gRenderer);
        void operator = (const Character& cpy);
        virtual ~Character();

    protected:

    private:
        int x;
        int y;
        int width;
        int height;
        SDL_Rect sprite_clips;
        LTexture* image;
        int ascii;

};

#endif // CHARACTER_H
