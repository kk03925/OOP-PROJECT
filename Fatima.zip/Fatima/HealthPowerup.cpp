#include "HealthPowerup.h"


HealthPowerup::HealthPowerup(LTexture* image, float x, float y): Powerup(image, x ,y) //assigns relevant attributes
{
    this-> image = image;
    this -> x = x;
    this -> y = y;
    colRecWidth = 28;
    colRecHeight = 35;
    type = HEALTHPOWERUP;
}

void HealthPowerup:: Render(long int& frame, SDL_Renderer* gRenderer ) //renders
{
    image->RenderTexture(x+scroll, y,gRenderer, NULL , 0, NULL, 1);
}


HealthPowerup::~HealthPowerup()
{
    //dtor
}
