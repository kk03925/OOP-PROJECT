#include "Character.h"

Character::Character()
{

}

Character::Character(LTexture* image, float x, float y, int ascii_val) //assigns relevant attributes
{
    this -> image = image;
    ascii = 65;
    width = 80;
    height = 71;
    this->x = x;
    this->y = y;
    sprite_clips.x = 0;
    sprite_clips.y = 0;

    if (ascii_val == 32) //accounts for space
    {
        sprite_clips.x = 837;
        sprite_clips.y = 503;
    }

    else if (ascii_val > 65 && ascii_val <= 76) //assigns clip values for each character
    {
        while (ascii!= ascii_val)
        {
            ascii++;
            sprite_clips.x = sprite_clips.x+ width;
        }

    }

    else if (ascii_val > 76 && ascii_val <= 88)
    {
        sprite_clips.y = sprite_clips.y + height;
        ascii = 77;
        while (ascii!= ascii_val)
        {
            ascii++;
            sprite_clips.x = sprite_clips.x+ width;
        }
    }

    else if (ascii_val > 88 && ascii_val <= 90)
    {
        sprite_clips.y = sprite_clips.y + height*2;
        ascii = 89;
        while (ascii!= ascii_val)
        {
            ascii++;
            sprite_clips.x = sprite_clips.x+ width;
        }
    }
    sprite_clips.w = width;
    sprite_clips.h = height;
}

void Character::Render(long int&, SDL_Renderer* gRenderer)
{
    image->RenderTexture( x , y , gRenderer, &sprite_clips, 0, NULL,0.4);

}

void Character::operator = (const Character& cpy) //used to copy character values easily
{
    this->x=cpy.x;
    this -> y = cpy.y;
    this->sprite_clips=cpy.sprite_clips;

    this->image=cpy.image;
    this->ascii=cpy.ascii;
    this->width=cpy.width;
    this->height=cpy.height;
}

Character::~Character()
{
    //dtor
}
