#include "Player.h"

Player::Player(LTexture* image, LTexture* health_image, LTexture* health_icon,LTexture* milk_bar, LTexture* milk,float x,float y,float WorldX , float WorldY): Object(image, x, y, WorldX, WorldY )
{
    this->image = image;
    this -> bar1 = health_image;
    this -> bar2 = milk_bar;
    this -> health_icon = health_icon;
    this -> milk = milk;
    health_bar = new HealthBar(bar1,health_icon,0,0);
    qauntity_bar = new QuantityBar(bar2, milk, 0 ,0 );

    milk_quantity = 19;
    health = 100;
    x=0;
    y = 400;
    type = 0;
    type = 0;
    damageCaused = 33;
    colRecWidth = 70;
    colRecHeight = 115;

    //Set sprite clips
    gStandingSpriteClips [ 0 ].x = 38;
    gStandingSpriteClips [ 0 ].y = 41;
    gStandingSpriteClips [ 0 ].w = 50;
    gStandingSpriteClips [ 0 ].h = 122;

    gStandingSpriteClips [ 1 ].x = 1200;
    gStandingSpriteClips [ 1 ].y = 38;
    gStandingSpriteClips [ 1 ].w = 48;
    gStandingSpriteClips [ 1 ].h = 123;

    gWalkingRightSpriteClips[ 0 ].x =   45;
    gWalkingRightSpriteClips[ 0 ].y =   176;
    gWalkingRightSpriteClips[ 0 ].w =  64;
    gWalkingRightSpriteClips[ 0 ].h = 115;

    gWalkingRightSpriteClips[ 1 ].x =   117;
    gWalkingRightSpriteClips[ 1 ].y =   179;
    gWalkingRightSpriteClips[ 1 ].w =  55;
    gWalkingRightSpriteClips[ 1 ].h = 112;

    gWalkingRightSpriteClips[ 2 ].x =   187;
    gWalkingRightSpriteClips[ 2 ].y =   177;
    gWalkingRightSpriteClips[ 2 ].w =  52;
    gWalkingRightSpriteClips[ 2 ].h = 117;

    gWalkingRightSpriteClips[ 3 ].x =   248;
    gWalkingRightSpriteClips[ 3 ].y =   179;
    gWalkingRightSpriteClips[ 3 ].w =  65;
    gWalkingRightSpriteClips[ 3 ].h = 118;

    gWalkingRightSpriteClips[ 4 ].x =   324;
    gWalkingRightSpriteClips[ 4 ].y =   181;
    gWalkingRightSpriteClips[ 4 ].w =  78;
    gWalkingRightSpriteClips[ 4 ].h = 113;

    gWalkingRightSpriteClips[ 5 ].x =   413;
    gWalkingRightSpriteClips[ 5 ].y =   176;
    gWalkingRightSpriteClips[ 5 ].w =  72;
    gWalkingRightSpriteClips[ 5 ].h =  118;

    gWalkingRightSpriteClips[ 6 ].x =   499;
    gWalkingRightSpriteClips[ 6 ].y =   178;
    gWalkingRightSpriteClips[ 6 ].w =  61;
    gWalkingRightSpriteClips[ 6 ].h = 115;

    gWalkingRightSpriteClips[ 7 ].x =   571;
    gWalkingRightSpriteClips[ 7 ].y =   178;
    gWalkingRightSpriteClips[ 7 ].w =  48;
    gWalkingRightSpriteClips[ 7 ].h = 112;

    gWalkingRightSpriteClips[ 8 ].x =   628;
    gWalkingRightSpriteClips[ 8 ].y =   170;
    gWalkingRightSpriteClips[ 8 ].w =  58;
    gWalkingRightSpriteClips[ 8 ].h = 121;

    gWalkingRightSpriteClips[ 9 ].x =   694;
    gWalkingRightSpriteClips[ 9 ].y =   169;
    gWalkingRightSpriteClips[ 9 ].w =  74;
    gWalkingRightSpriteClips[ 9 ].h =   120;

    gWalkingRightSpriteClips[ 10 ].x =   772;
    gWalkingRightSpriteClips[ 10 ].y =   178;
    gWalkingRightSpriteClips[ 10 ].w =  81;
    gWalkingRightSpriteClips[ 10 ].h = 115;

    gWalkingRightSpriteClips[ 11 ].x =   869;
    gWalkingRightSpriteClips[ 11 ].y =   173;
    gWalkingRightSpriteClips[ 11 ].w =  66;
    gWalkingRightSpriteClips[ 11 ].h = 118;

    gWalkingLeftSpriteClips[ 0 ].x =   1935;
    gWalkingLeftSpriteClips[ 0 ].y =   175;
    gWalkingLeftSpriteClips[ 0 ].w =  65;
    gWalkingLeftSpriteClips[ 0 ].h = 116;

    gWalkingLeftSpriteClips[ 1 ].x =   1870;
    gWalkingLeftSpriteClips[ 1 ].y =   176;
    gWalkingLeftSpriteClips[ 1 ].w =  57;
    gWalkingLeftSpriteClips[ 1 ].h = 113;

    gWalkingLeftSpriteClips[ 2 ].x =   1807;
    gWalkingLeftSpriteClips[ 2 ].y =   175;
    gWalkingLeftSpriteClips[ 2 ].w =  52;
    gWalkingLeftSpriteClips[ 2 ].h = 118;

    gWalkingLeftSpriteClips[ 3 ].x =   1733;
    gWalkingLeftSpriteClips[ 3 ].y =   176;
    gWalkingLeftSpriteClips[ 3 ].w =  65;
    gWalkingLeftSpriteClips[ 3 ].h = 121;


    gWalkingLeftSpriteClips[ 4 ].x =   1644;
    gWalkingLeftSpriteClips[ 4 ].y =   179;
    gWalkingLeftSpriteClips[ 4 ].w =  79;
    gWalkingLeftSpriteClips[ 4 ].h = 115;

    gWalkingLeftSpriteClips[ 5 ].x =   1560;
    gWalkingLeftSpriteClips[ 5 ].y =   177;
    gWalkingLeftSpriteClips[ 5 ].w =  75;
    gWalkingLeftSpriteClips[ 5 ].h = 117;

    gWalkingLeftSpriteClips[ 6 ].x =   1483;
    gWalkingLeftSpriteClips[ 6 ].y =   176;
    gWalkingLeftSpriteClips[ 6 ].w =  64;
    gWalkingLeftSpriteClips[ 6 ].h = 114;

    gWalkingLeftSpriteClips[ 7 ].x =   1424;
    gWalkingLeftSpriteClips[ 7 ].y =   176;
    gWalkingLeftSpriteClips[ 7 ].w =  54;
    gWalkingLeftSpriteClips[ 7 ].h = 114;

    gWalkingLeftSpriteClips[ 8 ].x =   1359;
    gWalkingLeftSpriteClips[ 8 ].y =   171;
    gWalkingLeftSpriteClips[ 8 ].w =  60;
    gWalkingLeftSpriteClips[ 8 ].h = 121;

    gWalkingLeftSpriteClips[ 9 ].x =   1278;
    gWalkingLeftSpriteClips[ 9 ].y =   168;
    gWalkingLeftSpriteClips[ 9 ].w =  72;
    gWalkingLeftSpriteClips[ 9 ].h = 122;

    gWalkingLeftSpriteClips[ 10 ].x =   1192;
    gWalkingLeftSpriteClips[ 10 ].y =   178;
    gWalkingLeftSpriteClips[ 10 ].w =  82;
    gWalkingLeftSpriteClips[ 10 ].h = 115;

    gWalkingLeftSpriteClips[ 11 ].x =   1109;
    gWalkingLeftSpriteClips[ 11 ].y =   172;
    gWalkingLeftSpriteClips[ 11 ].w =  66;
    gWalkingLeftSpriteClips[ 11 ].h =   121;

    gJumpingRightSpriteClips [0].x = 45;
    gJumpingRightSpriteClips [0].y = 709;
    gJumpingRightSpriteClips [0].w = 62;
    gJumpingRightSpriteClips [0].h = 118;

    gJumpingRightSpriteClips [1].x = 107;
    gJumpingRightSpriteClips [1].y = 715;
    gJumpingRightSpriteClips [1].w = 70;
    gJumpingRightSpriteClips [1].h = 120;

    gJumpingRightSpriteClips [2].x = 179;
    gJumpingRightSpriteClips [2].y = 715;
    gJumpingRightSpriteClips [2].w = 76;
    gJumpingRightSpriteClips [2].h = 126;

    gJumpingRightSpriteClips [3].x = 259;
    gJumpingRightSpriteClips [3].y = 712;
    gJumpingRightSpriteClips [3].w = 78;
    gJumpingRightSpriteClips [3].h = 107;

    gJumpingRightSpriteClips [4].x = 347;
    gJumpingRightSpriteClips [4].y = 718;
    gJumpingRightSpriteClips [4].w = 88;
    gJumpingRightSpriteClips [4].h = 103;

    gJumpingRightSpriteClips [5].x = 456;
    gJumpingRightSpriteClips [5].y = 716;
    gJumpingRightSpriteClips [5].w = 90;
    gJumpingRightSpriteClips [5].h = 109;

    gJumpingRightSpriteClips [6].x = 555;
    gJumpingRightSpriteClips [6].y = 717;
    gJumpingRightSpriteClips [6].w = 89;
    gJumpingRightSpriteClips [6].h = 108;

    gJumpingRightSpriteClips [7].x = 666;
    gJumpingRightSpriteClips [7].y = 717;
    gJumpingRightSpriteClips [7].w = 75;
    gJumpingRightSpriteClips [7].h = 112;

    gJumpingRightSpriteClips [8].x = 760;
    gJumpingRightSpriteClips [8].y = 716;
    gJumpingRightSpriteClips [8].w = 70;
    gJumpingRightSpriteClips [8].h = 124;

    gJumpingLeftSpriteClips [0].x = 1937;
    gJumpingLeftSpriteClips [0].y = 708;
    gJumpingLeftSpriteClips [0].w = 62;
    gJumpingLeftSpriteClips [0].h = 116;

    gJumpingLeftSpriteClips [1].x = 1868;
    gJumpingLeftSpriteClips [1].y = 715;
    gJumpingLeftSpriteClips [1].w = 71;
    gJumpingLeftSpriteClips [1].h = 120;

    gJumpingLeftSpriteClips [2].x = 1788;
    gJumpingLeftSpriteClips [2].y = 714;
    gJumpingLeftSpriteClips [2].w = 77;
    gJumpingLeftSpriteClips [2].h = 126;

    gJumpingLeftSpriteClips [3].x = 1709;
    gJumpingLeftSpriteClips [3].y = 712;
    gJumpingLeftSpriteClips [3].w = 78;
    gJumpingLeftSpriteClips [3].h = 108;

    gJumpingLeftSpriteClips [4].x = 1611;
    gJumpingLeftSpriteClips [4].y = 718;
    gJumpingLeftSpriteClips [4].w = 86;
    gJumpingLeftSpriteClips [4].h = 104;

    gJumpingLeftSpriteClips [5].x = 1500;
    gJumpingLeftSpriteClips [5].y = 716;
    gJumpingLeftSpriteClips [5].w = 89;
    gJumpingLeftSpriteClips [5].h = 109;

    gJumpingLeftSpriteClips [6].x = 1401;
    gJumpingLeftSpriteClips [6].y = 718;
    gJumpingLeftSpriteClips [6].w = 89;
    gJumpingLeftSpriteClips [6].h = 108;

    gJumpingLeftSpriteClips [7].x = 1304;
    gJumpingLeftSpriteClips [7].y = 717;
    gJumpingLeftSpriteClips [7].w = 74;
    gJumpingLeftSpriteClips [7].h = 112;

    gJumpingLeftSpriteClips [8].x = 1213;
    gJumpingLeftSpriteClips [8].y = 716;
    gJumpingLeftSpriteClips [8].w = 71;
    gJumpingLeftSpriteClips [8].h = 122;

    gThrowingSpriteClips[0].x= 312;
    gThrowingSpriteClips[0].y= 55;
    gThrowingSpriteClips[0].w= 99;
    gThrowingSpriteClips[0].h= 102;

    gThrowingSpriteClips[1].x= 1633;
    gThrowingSpriteClips[1].y= 55;
    gThrowingSpriteClips[1].w= 100;
    gThrowingSpriteClips[1].h= 102;


    alive = true;
}

void Player::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (frame % 50 == 0)
    {
        AnimationFrame++; //to control speed of the clips rendering of the ghosts
    }

    if (alive)
    {
        if (movement==true)
        {
            if (direction==0)
            {
                image->RenderTexture(x,y, gRenderer,&gWalkingRightSpriteClips[AnimationFrame%12],0, NULL, 1);
            }
            else if (direction == 1 )
            {
                image->RenderTexture(x,y, gRenderer,&gWalkingLeftSpriteClips[AnimationFrame%12],0, NULL, 1);
            }
        }
        else
        {
            if (inJump == false)
            {
                image->RenderTexture(x,y, gRenderer,&gStandingSpriteClips[direction],0, NULL, 1);
            }
            else
            {
                image->RenderTexture(x,y,gRenderer,&gJumpingRightSpriteClips[AnimationFrame%9],0,NULL,1);
            }
        }
    }

    if (AnimationFrame >= 12)
    {
        AnimationFrame = 0;
    }
    health_bar -> Render(frame, health, gRenderer);
    qauntity_bar -> Render(frame, milk_quantity, gRenderer);
}

void Player::Move(int direction)
{
    if (alive)
    {
        if(direction==LEFT)
        {
            WorldX-=WORLD_COORD_CHANGE_PER_CLICK;
        }
        if(direction==RIGHT)
        {
            WorldX +=WORLD_COORD_CHANGE_PER_CLICK;
        }
    }
}


void Player::handleEvent(SDL_Event& e)
{
    if (e.type == SDL_KEYDOWN && e.key.repeat ==0)
    {
        switch (e.key.keysym.sym)
        {
            case (SDLK_LEFT ) :
            {
                cout<<"in left"<<endl;
                direction = 1;
                movement = true;
                mVelX -= PlayerVelocity;
                break;
            }
            case (SDLK_RIGHT) :
            {
                direction= 0;
                movement = true;
                mVelX += PlayerVelocity;
                break;
            }
            case (SDLK_SPACE):
            {
                movement = false;
                inJump = true;
                standing = true;
        }
    }
    }

    else if (e.type == SDL_KEYUP && e.key.repeat ==0)
    {
        switch (e.key.keysym.sym)
        {
            case (SDLK_LEFT)  :
            {
                movement = false;
                mVelX += PlayerVelocity;
                break;
            }
            case (SDLK_RIGHT) :
            {
                movement = false;
                mVelX -= PlayerVelocity;
                break;
            }
            case (SDLK_SPACE):
            {
                inJump = false;
            }
        }
    }
}

void Player::move()
{
    x +=mVelX;
    y +=mVelY;
}

Player::~Player()
{
    cout<<"Aladdin destroyed"<<endl;
}

void Player::SetHealth()
{
    if (health < 3)
    {
        health++;
    }
}

void Player::SetQuantity()
{
    if (milk_quantity <20)
    {
        milk_quantity++;
    }
}

bool Player::GetLife()
{
    return alive;

}

void Player::SetX(float passedX)
{
    x = passedX;
}
