#include "Enemy.h"

Enemy::Enemy(LTexture* image,float x, float y,float worldX,float worldY) : Object(image,x,y,worldX,worldY) //Specifying k object ka ye wala constructor call ho
{

}
void Enemy::Attack(float)
{

}

Enemy::~Enemy()
{
    //dtor
}




