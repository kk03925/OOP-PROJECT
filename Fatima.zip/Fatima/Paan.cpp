#include "Paan.h"

Paan::Paan()
{
    //ctor
}

Paan::Paan(LTexture* image, float x, float y) : Traps(image, x, y)
{
    this->image = image;
    this->x = x;
    this->y = y;
    this->type = PAAN;
}

void Paan::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x+scroll, y,gRenderer, NULL , 0, NULL, 3);
}

Paan::~Paan()
{
    //dtor
}
