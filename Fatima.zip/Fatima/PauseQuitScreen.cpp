#include "PauseQuitScreen.h"

PauseQuitScreen::PauseQuitScreen(LTexture* bg_image, LTexture* button, LTexture* text_texture) : MenuScreen(bg_image, button, text_texture)
{
    this->bg_image = bg_image;
    this->button_sprite = button;
    this -> text_sprite = text_texture;
    float y = 150;
    button_count = 2;
    buttons = new Button[button_count];
    string buttons_text[2] = {"RESUME", "  MENU  "};
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Init(button_sprite, text_sprite, 350, y, buttons_text[i], 0);
        y = y + 100;
    }
}

void PauseQuitScreen::Render(long int& frame,SDL_Renderer* gRenderer)
{
    SDL_Rect rect = {0, 0, 1024, 576};
    bg_image->RenderTexture( 180, 80,gRenderer, &rect, 0, NULL,0.6);
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Render(frame, gRenderer);
    }
}

PauseQuitScreen::~PauseQuitScreen()
{
    delete[] buttons;
    cout<<"Pause Screen Destroyed"<<endl;
}
