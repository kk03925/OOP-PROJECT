#include "PauseQuitScreen.h"

//assigns relevant values to the attributes
PauseQuitScreen::PauseQuitScreen(LTexture* bg_image, LTexture* button, LTexture* text_texture) : MenuScreen(bg_image, button, text_texture)
{
    this->bg_image = bg_image;
    this->button_sprite = button;
    this -> text_sprite = text_texture;
    float y = 150;
    button_count = 2;
    buttons = new Button[button_count]; //creates a dynamic button array
    string buttons_text[2] = {"RESUME", "  MENU  "}; //array of button text
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Init(button_sprite, text_sprite, 350, y, buttons_text[i], 0); //copies relevant info the button
        y = y + 100;
    }
}

void PauseQuitScreen::Render(long int& frame,SDL_Renderer* gRenderer) //renders screen and the buttons
{
    SDL_Rect rect = {0, 0, 1024, 576}; //dest rect for the screen
    bg_image->RenderTexture( 180, 80,gRenderer, &rect, 0, NULL,0.6);
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Render(frame, gRenderer);
    }
}

PauseQuitScreen::~PauseQuitScreen()
{
    delete[] buttons;
    cout<<"Pause Screen Destroyed"<<endl;
}
