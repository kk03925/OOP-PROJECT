#include "GameScreen.h"

GameScreen::GameScreen(LTexture* image_one, LTexture* button, LTexture* text_texture, LTexture* image_two, LTexture* image_three):
    MenuScreen(bg_image, button, text_texture) //assigns relevant values to the attributes
{
    this->bg_image = image_one;
    this-> image_two = image_two;
    this->image_three = image_three;
    this -> button_sprite = button;
    this -> text_sprite = text_texture;
    button_count = 1;
    buttons = new Button[button_count]; //creates a dynamic array
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Init(button_sprite, text_sprite, 990, 0, "" , 1); //copies relevant values to the button
    }
}
void GameScreen::Render(long int& frame, float& scroll_one, float& scroll_two, float& scroll_three, SDL_Renderer* gRenderer)
{
    //renders the three different backgrounds used to create parallax effect and the button
    bg_image -> RenderTexture( scroll_one, 0, gRenderer, NULL, 0, NULL, 1.25);
    image_two -> RenderTexture( scroll_two, 110, gRenderer, NULL, 0, NULL, 0.8);
    image_three -> RenderTexture( scroll_three, 58, gRenderer, NULL, 0, NULL, 0.9);
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Render(frame, gRenderer);
    }
}

GameScreen::~GameScreen()
{
    delete[] buttons;
    cout<< "Game Screen no more."<<endl;
}
