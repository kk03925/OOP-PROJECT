#ifndef BRICK FACTORY_H
#define BRICK FACTORY_H
#include "Brick.h"

class Brick Factory
{
    public:
        Brick Factory();
        Brick* GetBrick(LTexture* image, int x, int y,int minimum, int maximum, int type);
        virtual ~Brick Factory();

    protected:

    private:
        Brick* brick;

};

#endif // BRICK FACTORY_H
