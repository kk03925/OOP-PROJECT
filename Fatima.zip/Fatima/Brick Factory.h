#ifndef BRICK FACTORY_H
#define BRICK FACTORY_H
#include "Brick.h"

class BrickFactory
{
    public:
        BrickFactory();
        Brick* GetBrick(LTexture* image, int x, int y,int minimum, int maximum, int type);
        virtual ~BrickFactory();

    protected:

    private:
        Brick* brick;

};

#endif // BRICK FACTORY_H
