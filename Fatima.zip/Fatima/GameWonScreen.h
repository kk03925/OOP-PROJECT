#ifndef GAMEWONSCREEN_H
#define GAMEWONSCREEN_H
#include "MenuScreen.h"


class GameWonScreen: public MenuScreen
{
    public:
        GameWonScreen(LTexture*, LTexture*, LTexture*);
        virtual ~GameWonScreen();

    protected:

    private:
};

#endif // GAMEWONSCREEN_H
