#include "StandardBrick.h"

StandardBrick::StandardBrick()
{

}

StandardBrick::StandardBrick(LTexture* image, float x, float y) : Brick(image, x,  y)
{
    this->image = image;
    this->x = x;
    this->y = y;
    this->type = STANDARDBRICK;
}

void StandardBrick::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x+scroll, y, gRenderer, NULL, 0, NULL, 0.25);
}

StandardBrick::~StandardBrick()
{

}
