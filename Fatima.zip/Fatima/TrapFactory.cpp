#include "TrapFactory.h"
#include "Paan.h"
#include "Gutter.h"

TrapFactory::TrapFactory()
{
    //ctor
}

Traps* TrapFactory::GetTrap(LTexture* image, float x, float y, int type)  // creates the relevant power and returns it
{
    if(type == 0)
    {
        trap = new Paan(image, x, y);
    }

    if(type == 1)
    {
        trap = new Gutter(image, x, y);
    }
    return trap;
}

TrapFactory::~TrapFactory()
{
    //dtor
}
