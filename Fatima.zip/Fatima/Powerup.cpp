#include "Powerup.h"


Powerup::Powerup(LTexture* image, float x, float y): Object(image,x,y,x,y) //overloaded constructor
{
    this -> image = image;
    this -> x = x;
    this -> y = y;
    scroll = 0;
}

void Powerup::Render(long int& frame, SDL_Renderer* gRenderer) //renders
{
    image->RenderTexture(x, y,gRenderer, NULL , 0, NULL, 1);
}

int Powerup::GetType()
{
    return type;
}

void Powerup::SetScroll(float scroll)
{
    this->scroll = scroll;
}

Powerup::~Powerup()
{
    //dtor
}
