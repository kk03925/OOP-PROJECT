#ifndef PLAYER_H
#define PLAYER_H
#include "QuantityBar.h"
#include "LTexture.h"
#include "Constants.h"
#include "HealthBar.h"
#include "StrengthBar.h"
#include <math.h>
#include "Object.h"

#define PI 3.14159265

class Player: public Object

{
   public:
        Player(LTexture*, HealthBar*, QuantityBar*, StrengthBar*,float,float,float,float);
        void Render(long int&, SDL_Renderer*);
        virtual ~Player();
        int direction = 0;
        int AnimationFrame = 0;
        bool movement;
        bool standing;
        bool inJump;
        bool ifThrowing;
        void handleEvent( SDL_Event& e );
        void move();
        void Move(int);
        void SetHealth();
        void SetQuantity();
        void SetStrength();
        void SetX(float);
        bool GetLife();
        static const int PlayerVelocity = 1;
        static const int jumpDistance = 2;

    private:
		int mVelX = 0;
		float mVelY = 0;

		int health;
		int milk_quantity;
		int strength;

		HealthBar* health_bar;
		QuantityBar* qauntity_bar;
		StrengthBar* strength_bar;


        SDL_Rect gWalkingRightSpriteClips[ 12 ];
        SDL_Rect gWalkingLeftSpriteClips[ 12 ];
        SDL_Rect gThrowingSpriteClips[ 2 ];
        SDL_Rect gDuckingSpriteClips[ 1 ];
        SDL_Rect gStandingSpriteClips [ 2];
        SDL_Rect gJumpingRightSpriteClips [9];
        SDL_Rect gJumpingLeftSpriteClips [9];
};

#endif // PLAYER_H
