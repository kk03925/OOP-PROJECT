#ifndef PAAN_H
#define PAAN_H
#include "Traps.h"

class Paan : public Traps
{
    public:
        Paan();
        Paan(LTexture*, float, float);
        void Render(long int&, SDL_Renderer*);
        virtual ~Paan();

    protected:
        const int damage = 0.1;
    private:
};

#endif // PAAN_H
