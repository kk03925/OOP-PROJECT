#include "BarClass.h"

BarClass::BarClass(): Object()
{

}

BarClass::BarClass(LTexture* image, LTexture* icon_image): Object(image,x, y, WorldX,WorldY) //overloaded constructor
{
    this -> image = image;
    this -> icon_image = icon_image;

}

void BarClass::Render(long int&,  SDL_Renderer*)
{

}

BarClass::~BarClass()
{
    //dtor
}

