#include "BarClass.h"



BarClass::BarClass(LTexture* image): Object(image,x, y, WorldX,WorldY)
{
    this -> image = image;
}

void BarClass::Render(long int&, SDL_Renderer*)
{

}
BarClass::~BarClass()
{
    //dtor
}
