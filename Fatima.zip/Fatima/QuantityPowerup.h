#ifndef QUANTITYPOWERUP_H
#define QUANTITYPOWERUP_H

#include "Powerup.h"

class QuantityPowerup: public Powerup
{
    public:
        QuantityPowerup();
        QuantityPowerup(LTexture*, float, float);
        void Render(long int&, SDL_Renderer*);
        virtual ~QuantityPowerup();

    protected:

    private:
};

#endif // QUANTITYPOWERUP_H
