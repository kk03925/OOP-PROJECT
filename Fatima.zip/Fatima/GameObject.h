#ifndef GAMEOBJECT_H
#define GAMEOBJECT_H
#include "LTexture.h"


class GameObject
{
    public:
        GameObject();
        GameObject(LTexture*);
        virtual void Render(long int&, SDL_Renderer*) = 0;
        virtual ~GameObject();
        float GetX();
        float GetY();
        void SetX(int);

    protected:
        LTexture* image;
        float x = 0;
		float y = 0;

    private:

};

#endif // GAMEOBJECT_H
