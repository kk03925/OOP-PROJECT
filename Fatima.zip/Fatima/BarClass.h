#ifndef BARCLASS_H
#define BARCLASS_H
#include "GameObject.h"
#include "Object.h"
#include "LTexture.h"

class BarClass: public Object
{
    public:
        BarClass();
        BarClass(LTexture*);
        void Render(long int&, SDL_Renderer*);
        virtual ~BarClass();

    protected:
        SDL_Rect bar;
        SDL_Rect icon;
    private:


};

#endif // BARCLASS_H
