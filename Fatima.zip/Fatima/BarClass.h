#ifndef BARCLASS_H
#define BARCLASS_H
#include "Object.h"

class BarClass: public Object
{
    public:
        BarClass();
        BarClass(LTexture*, LTexture*); //overloaded constructor
        virtual void Render(long int&, SDL_Renderer*); //to render
        virtual ~BarClass();

    protected:
        SDL_Rect bar; //the dest rect for the bar
        LTexture* icon_image; //texture for the icon

};

#endif // BARCLASS_H
