#include "Word.h"

Word::Word()
{
    width =0;
    height = 0;
    text = "\0";
    word_len = 0;
    characters = NULL;
}

Word::Word(string text, LTexture* image, float x, float y)
{
    this->image = image;
    word_len = text.size();
    width = 32*word_len;
    height = 71;
    this->text = text;
    characters = new Character[word_len]; //create a dynamic array of characters
    this->x = x;
    this->y = y;
    for(int i=0; i<word_len; i++)
    {
        characters[i] = Character(image, x+32*i ,y + 7, (int)text[i]); //make charaters and store that in dynamic array
    }
}

void Word::Render(long int& frame, SDL_Renderer* gRenderer)
{
   for(int i=0; i<word_len; i++)
    {
        characters[i].Render(frame, gRenderer);
    }
}

int Word::GetLength()
{
    return word_len;
}

int Word::GetWidth()
{
    return width;
}

Word::~Word()
{
    cout << "Word " << text << " is destroyed" << endl;
    if (characters!=NULL)
    {
        delete[] characters; //deallocating dynamic array
        characters = NULL;
    }
}
