#include "FactoryProducer.h"

FactoryProducer::FactoryProducer()
{
    //ctor
}

FactoryProducer::~FactoryProducer()
{
    //dtor
}
