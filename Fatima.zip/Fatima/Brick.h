#ifndef BRICK_H
#define BRICK_H
#include "LTexture.h"
#include "Object.h"

class Brick : public Object
{
    public:
        Brick();
        Brick(LTexture*, float, float);
        int GetStrType();
        void SetScroll(float);
        virtual void Render(long int&, SDL_Renderer*) = 0;
        virtual ~Brick();

    protected:
        float scroll;
        int type;
};

#endif // BRICK_H
