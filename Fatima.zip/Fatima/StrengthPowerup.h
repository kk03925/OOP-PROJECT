#ifndef STRENGTHPOWERUP_H
#define STRENGTHPOWERUP_H
#include "Powerup.h"


class StrengthPowerup: public Powerup
{
    public:
        StrengthPowerup();
        StrengthPowerup(LTexture*, float, float);
        void Render(long int&, SDL_Renderer*);
        virtual ~StrengthPowerup();

    protected:

    private:
};

#endif // STRENGTHPOWERUP_H
