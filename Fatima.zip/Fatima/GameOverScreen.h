#ifndef GAMEOVERSCREEN_H
#define GAMEOVERSCREEN_H
#include "MenuScreen.h"
//#include <SDL_mixer.h>

class GameOverScreen: public MenuScreen
{
    public:
        GameOverScreen(LTexture*, LTexture*, LTexture*);
        virtual ~GameOverScreen();
};

#endif // GAMEOVERSCREEN_H
