#ifndef GUTTER_H
#define GUTTER_H
#include "Traps.h"

class Gutter : public Traps
{
    public:
        Gutter();
        Gutter(LTexture*, float, float);
        void Render(long int&, SDL_Renderer*);
        virtual ~Gutter();

    protected:

    private:
};

#endif // GUTTER_H
