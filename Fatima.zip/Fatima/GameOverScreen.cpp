#include "GameOverScreen.h"
//assigns relevant values to the attributes
GameOverScreen::GameOverScreen(LTexture* bg_image, LTexture* button, LTexture* text_texture) : MenuScreen(bg_image, button, text_texture)
{
    this->bg_image = bg_image;
    this->button_sprite = button;
    this -> text_sprite = text_texture;
    float y = 280;
    button_count = 2;
    buttons = new Button[button_count]; //creates a dynamic button array
    string buttons_text[2] = {"NEW GAME","  MENU  "}; //array of button text
    for (int i = 0; i< button_count; i++)
    {
        buttons[i].Init(button_sprite, text_sprite, 350, y, buttons_text[i], 0); //copies relevant info the button
        y = y + 100;
    }
}


GameOverScreen::~GameOverScreen()
{
    delete[] buttons;
    cout<<"Game Over GameOverScreen Destroyed"<<endl;
}
