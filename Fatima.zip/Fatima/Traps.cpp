#include "Traps.h"

Traps::Traps()
{
    //ctor
}

Traps::Traps(LTexture* image, float x, float y) : Object(image,x,y,x+50,y+100)
{
    this->image = image;
    this->x = x;
    this->y = y;
    this->scroll = 0;
}

void Traps::SetScroll(float scroll)
{
    this->scroll = scroll;
}

void Traps::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x, y,gRenderer, NULL , 0, NULL, 1);
}

int Traps::GetStrType()
{
    return type;
}

Traps::~Traps()
{
    //dtor
}
