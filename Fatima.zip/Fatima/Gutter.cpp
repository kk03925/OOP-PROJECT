#include "Gutter.h"

Gutter::Gutter()
{
    //ctor
}

Gutter::Gutter(LTexture* image, float x, float y) : Traps(image, x, y)
{
    this->image = image;
    this->x = x;
    this->y = y;
    this->type = GUTTER;
}

void Gutter::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x+scroll, y,gRenderer, NULL , 0, NULL, 4);
}

Gutter::~Gutter()
{
    //dtor
}
