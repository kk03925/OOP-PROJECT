#ifndef ENEMY_H
#define ENEMY_H
#include "LTexture.h"
#include "Object.h"

class Enemy : public Object
{
    public:
        Enemy(LTexture*,float,float,float,float);
        ~Enemy();
        virtual void Attack(float);

    protected:
        int direction;

    private:

};

#endif // ENEMY_H
