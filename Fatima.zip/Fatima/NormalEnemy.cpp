#include "NormalEnemy.h"


NormalEnemy::NormalEnemy(LTexture* image,float x,float y,float worldx,float worldy) : Enemy(image,x,y,worldx,worldy)
{



}
void NormalEnemy::Attack(float worldx)
{
    if (this->x - worldx < 100)
    {
        cout<<"in range"<<endl;
    }

}

NormalEnemy::~NormalEnemy()
{
    //dtor
}
