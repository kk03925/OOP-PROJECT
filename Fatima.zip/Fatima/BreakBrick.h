#ifndef BREAKBRICK_H
#define BREAKBRICK_H
#include "Brick.h"

class BreakBrick : public Brick
{
    public:
        BreakBrick();
        BreakBrick(LTexture* , float, float);
        void Break();
        void Render(long int& frame,SDL_Renderer* gRenderer);
        virtual ~BreakBrick();

    protected:

    private:
};

#endif // BREAKBRICK_H
