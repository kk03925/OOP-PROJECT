#include "Weapons.h"

Weapons::Weapons()
{

}

Weapons::~Weapons()
{

}
