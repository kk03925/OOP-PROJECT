#include "Weapons.h"

Weapons::Weapons(LTexture*,float,float,float,float)
{

}

Weapons::~Weapons()
{

}
