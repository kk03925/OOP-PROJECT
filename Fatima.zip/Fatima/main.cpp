#include <stdio.h>
#include <string>
#include "string.h"
#include <iostream>
#include <SDL.h>
#include <SDL_image.h>
//#include <SDL_mixer.h>
#include "BarClass.h"
#include "Barrells.h"
#include "Button.h"
#include "Character.h"
#include "CleverEnemy.h"
#include "Enemy.h"
#include "GameScreen.h"
#include "GameOverScreen.h"
#include "GameWonScreen.h"
#include "HealthBar.h"
#include "HealthPowerup.h"
#include "LinkedList.h"
#include "LTexture.h"
#include "MenuScreen.h"
#include "NormalEnemy.h"
#include "PauseQuitScreen.h"
#include "Player.h"
#include "Powerup.h"
#include "QuantityBar.h"
#include "QuantityPowerup.h"
#include "PowerupFactory.h"
#include "Screen.h"
#include "SplashScreen.h"
#include "StrengthBar.h"
#include "Object.h"
#include "Traps.h"
#include "TrapFactory.h"
#include "Paan.h"
#include "Gutter.h"
using namespace std;

//The background scrolling offset
float scroll_one = 0;
float scroll_two = 0;
float scroll_three = 0;

//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

void close();

void SetAlpha();

void CheckCollisionPowerup(Player* player, Powerup* powerup);
void CheckCollisionTraps(Player* player, Traps* trap);

//Loads individual image as texture

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;
//LTexture gDotTexture;
LTexture splash_texture;
LTexture menu_texture;
LTexture game_texture_one;
LTexture game_texture_two;
LTexture game_texture_three;
LTexture button;
LTexture text_texture;
LTexture Aladdin;
LTexture cenemy;
LTexture health_bar;
LTexture quantity_bar;
LTexture health_icon;
LTexture quantity_icon;
LTexture game_over_texture;
LTexture health_glass;
LTexture strength_bar;
LTexture strength_icon;
LTexture quantity_glass;
LTexture pause_screen_texture;
LTexture game_won_texture;
LTexture strength_theli;
LTexture paan_image;
LTexture gutter_image;


//Mix_Chunk* click = NULL;
bool is_splash = true;
bool is_menu = false;
bool is_game = false;
bool game_over = false;
bool is_pause = false;

//Alpha Modulation component
float opaque = 255; //one component is set to full opaque
float trasparency = 0; //other is full transparent

void SaveGame(Player* aladdin)
{
   std::ofstream file;
   file.open("GameData.csv");
   file << scroll_one << "\n";
   file << scroll_two << "\n";
   file << scroll_three << "\n";
   file << aladdin->GetHealth() << "\n";
   file << aladdin-> GetQuantity() << "\n";
   file << aladdin -> GetX() << "\n";

}

void LoadGame(Player* aladdin)
{
    ifstream file ("GameData.csv");
    string line;
    if (file.is_open())
    {
        getline(file, line);
        scroll_one = atoi(line.c_str());
        getline(file, line);
        scroll_two = atoi(line.c_str());
        getline(file, line);
        scroll_three = atoi(line.c_str());
        getline(file, line);
        aladdin->SetHealth(atoi(line.c_str()));
        getline(file, line);
        aladdin->SetQuantity(atoi(line.c_str()));
        getline(file, line);
        aladdin->SetX(atoi(line.c_str()));

    }


}

bool init()
{
	//Initialization of flag
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
        if( gWindow == NULL )
        {
            printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
            success = false;
        }
        else
        {
            //Create renderer for window
            gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
            if( gRenderer == NULL )
            {
                printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
                success = false;
            }
            else
            {
                //Initialize renderer color
                SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

                //Initialize PNG loading
                int imgFlags = IMG_INIT_PNG;
                if( !( IMG_Init( imgFlags ) & imgFlags ) )
                {
                    printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
                    success = false;
                }
                //Initialize SDL_mixer
/*
                if( Mix_OpenAudio( 44100, MIX_DEFAULT_FORMAT, 2, 2048 ) < 0 )
                {
                    printf( "SDL_mixer could not initialize! SDL_mixer Error: %s\n", Mix_GetError() );
                    success = false;
                }
*/
            }
        }

    }
	return success;
}

bool loadMedia()
{
	///Loading success flag
	bool success = true;
    if( !splash_texture.LoadFromFile( "splash_screen.png", gRenderer  ) )
    {
        printf( "Failed to load splash sheet texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
        splash_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !button.LoadFromFile( "RedButtons.png", gRenderer  ) )
    {
        printf( "Failed to load button texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
        button.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !text_texture.LoadFromFile( "SpriteFon.png", gRenderer  ) )
    {
        printf("Failed to load text texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
        text_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !menu_texture.LoadFromFile( "menu_screen.png", gRenderer  ) )
    {
        printf( "Failed to load menu texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
        menu_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
/*
    click = Mix_LoadWAV("click.wav");

    if (click ==NULL)
    {
        printf( "Failed to load click music! SDL_mixer Error: %s\n", Mix_GetError() );
        success = false;
    }
*/
  if( !game_texture_one.LoadFromFile( "sky_bg.png", gRenderer  ) )
    {
        printf( "Failed to load game 1 texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       game_texture_one.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !game_texture_two.LoadFromFile( "building_bg.png", gRenderer  ) )
    {
        printf( "Failed to load game 2 sheet texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       game_texture_two.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !game_texture_three.LoadFromFile( "Bricks.png", gRenderer  ) )
    {
        printf( "Failed to load game 3 sheet texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
        game_texture_three.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !Aladdin.LoadFromFile( "Aladdin.png", gRenderer  ) )
    {
        printf( "Failed to load Aladdin texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
        Aladdin.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if(!health_bar.LoadFromFile("bar.png", gRenderer))
    {
        printf( "Failed to load health_bar texture!\n" );
        success = false;
    }
    else
    {
        health_bar.SetBlendMode(SDL_BLENDMODE_BLEND);
    }

    if(!quantity_bar.LoadFromFile("q_bar.png", gRenderer))
    {
        printf( "Failed to load health_bar texture!\n" );
        success = false;
    }
    else
    {
        quantity_bar.SetBlendMode(SDL_BLENDMODE_BLEND);
    }
    if(!health_icon.LoadFromFile("health.png", gRenderer))
    {
        printf( "Failed to load health_bar texture!\n" );
        success = false;
    }
    else
    {
        quantity_bar.SetBlendMode(SDL_BLENDMODE_BLEND);
    }
    if(!quantity_icon.LoadFromFile("milk.png", gRenderer))
    {
        printf( "Failed to load health_bar texture!\n" );
        success = false;
    }
    else
    {
        quantity_bar.SetBlendMode(SDL_BLENDMODE_BLEND);
    }

    if (!health_glass.LoadFromFile("health_powerup.png", gRenderer))
    {
        printf( "Failed to load health powerup texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       health_glass.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
    if (!quantity_glass.LoadFromFile("quantity_power.png", gRenderer))
    {
        printf( "Failed to load quantity powerup texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       quantity_glass.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
    if(!pause_screen_texture.LoadFromFile("pause_screen.png", gRenderer))
    {
        printf( "Failed to load  pause screen texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       pause_screen_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !game_over_texture.LoadFromFile( "game_over.png", gRenderer  ) )
    {
        printf( "Failed to load game over texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       game_over_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !game_won_texture.LoadFromFile( "game_won.png", gRenderer  ) )
    {
        printf( "Failed to load game won texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       game_won_texture.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if (!strength_theli.LoadFromFile("Theli.png", gRenderer))
    {
        printf( "Failed to load strength powerup texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       strength_theli.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
    if (!strength_bar.LoadFromFile("strength_bar.png", gRenderer))
    {
        printf( "Failed to load strength bar texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       strength_bar.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
    if (!strength_icon.LoadFromFile("strength_power.png", gRenderer))
    {
        printf( "Failed to load strength icon texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       strength_icon.SetBlendMode( SDL_BLENDMODE_BLEND );
    }

    if( !paan_image.LoadFromFile( "Paan.png", gRenderer  ) )
    {
        printf("Failed to load text texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
        paan_image.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
    if( !gutter_image.LoadFromFile( "gutter.png", gRenderer  ) )
    {
        printf("Failed to load text texture!\n" );
        success = false;
    }
    else
    {
        ///Set standard alpha blending
       gutter_image.SetBlendMode( SDL_BLENDMODE_BLEND );
    }
	//Nothing to load
	return success;
}

void close()
{
	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;
	splash_texture.Free();
	menu_texture.Free();
	button.Free();
	text_texture.Free();
	game_texture_one.Free();
	game_texture_two.Free();
	game_texture_three.Free();
	game_over_texture.Free();
	Aladdin.Free();

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}


int main( int argc, char* args[] )
{
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
	}
	else
	{
	    if( !loadMedia() )
		{
			printf( "Failed to load media!\n" );
		}
		else
		{
            LinkedList<Object*> * ObjectList = new LinkedList<Object*>();
            HealthBar health_bars(&health_bar, &health_icon,0,0);
		    QuantityBar quantity_bars(&quantity_bar, &quantity_icon, 0,0);
		    StrengthBar strength_bars (&strength_bar, &strength_icon, 0, 0);
            Player* aladdin = new Player(&Aladdin,&health_bars, &quantity_bars, &strength_bars, 30,400,50,450);
            CleverEnemy* enemy2 = new CleverEnemy(&cenemy,SCREEN_WIDTH-50,400,1590,450);
            PowerupFactory factory;
            Powerup* powerup;
            powerup = factory.GetPowerup(&strength_theli, 1400, 400, 2);
            //TrapFactory factory1;
            //Traps* trap;
           // trap = factory1.GetTrap(&gutter_image, 800, 490, 1);
           // Paan paan(&paan_image, 800, 510);
           // Paan paan2(&paan_image, 1500, 510);
         //   Gutter gutter1(&gutter_image, 1100, 490);
           // HealthPowerup* health_powerup_1 = new HealthPowerup(&health_glass, 1200, 400);
            //QuantityPowerup* quantity_powerup_1 = new QuantityPowerup(&quantity_glass, 800, 400);


			ObjectList->Push(aladdin);
			ObjectList->Push(enemy2);
			ObjectList->Push(powerup);
		//	ObjectList->Push(quantity_powerup_1);

            long int frame = 0;

            SplashScreen splash(&splash_texture);
            MenuScreen menu(&menu_texture, &button, &text_texture);
            GameScreen game_screen(&game_texture_one, &button, &text_texture,  &game_texture_two, &game_texture_three);
            PauseQuitScreen pause_screen(&pause_screen_texture, &button, &text_texture);
            GameWonScreen game_won_screen(&game_won_texture, &button, &text_texture);
            GameOverScreen game_over_screen(&game_over_texture, &button, &text_texture);

            aladdin->movement = false;

			bool quit = false;  //Main loop controller

			SDL_Event e;        //Event handler that takes care of all events

            int x,y;
            bool button_clicked = false;
            Button* buttons = NULL;



			//While application is running

			while( !quit )
			{
                while (SDL_PollEvent(&e))
                {
                    SDL_GetMouseState(&x,&y);

                    if( e.type == SDL_QUIT ) quit = true;
                    ObjectList->handleEvent(e);

                    if (e.type==SDL_MOUSEBUTTONDOWN)
                    {
                        if(e.button.button==SDL_BUTTON_LEFT)
                        {
                            button_clicked=true;
                            menu.MouseClick(x,y);
                            game_screen.MouseClick(x,y);
                            pause_screen.MouseClick(x,y);
                            game_over_screen.MouseClick(x,y);
                            game_won_screen.MouseClick(x,y);
                        }
                    }
                    else if (e.type == SDL_MOUSEMOTION) //to handle all mouse motion events for all screens
                    {
                        menu.MouseMotion(x,y);
                        game_screen.MouseMotion(x,y);
                        pause_screen.MouseMotion(x,y);
                        game_over_screen.MouseMotion(x,y);
                        game_won_screen.MouseMotion(x,y);
                    }
                    else if(e.type == SDL_MOUSEBUTTONUP && button_clicked) //tp handle all mouse click events for all screens
                    {

                        menu.MouseClick(x,y);
                        game_screen.MouseClick(x,y);
                        pause_screen.MouseClick(x,y);
                        game_over_screen.MouseClick(x,y);
                        game_won_screen.MouseClick(x,y);
                        button_clicked = false;
                    }
                }
                //Clear screen
				SDL_SetRenderDrawColor( gRenderer,  0, 0, 0, 0 );
				SDL_RenderClear( gRenderer );

                if(is_splash)       ///checks if Splash screen is running
                {
                    splash_texture.SetAlpha(opaque);     ///Splash Screen fades out with a decreasing
                    splash.Render(frame, gRenderer);       ///Rendering Splash Screen
                    if(opaque == 0)
                    {
                        is_splash = false;    ///indicates the end of splash screen run
                        is_menu = true;
                        opaque = 255; //reset
                        trasparency = 0; //reset
                    }
                }

                if (is_menu) //checks if menu running
                {
                    menu_texture.SetAlpha(255);
                    menu.Render(frame, gRenderer);

                    buttons = menu.GetButtons(); //gets buttons

                    for (int i =0; i < menu.GetButtonCount(); i++)  //loops over buttons and implements the button functionality
                    {
                        int state = buttons[i].GetState();

                        if (state == 2)
                        {
                            if(i == 0)
                            {
                                is_menu = false;
                                is_game = true;
                                scroll_one =0;
                                scroll_two = 0;
                                scroll_three = 0;
                                break;
                            }
                            else if(i == 1)
                            {
                                is_menu = false;
                                LoadGame(aladdin);
                                is_game = true;
                                break;
                            }

                            else if(i== 2)
                            {
                                quit = true;
                                break;
                            }
                        }
                    }
                }

                if (is_game) //checks is game is running
                {
                    game_texture_one.SetAlpha(255);
                    game_texture_two.SetAlpha(255);
                    game_texture_three.SetAlpha(255);
                    game_screen.Render(frame, scroll_one, scroll_two, scroll_three, gRenderer);
                    powerup->SetScroll(scroll_two);

                    ObjectList->Render(frame,gRenderer);
                    ObjectList->AladdinTracker();

                    CheckCollisionPowerup(aladdin,powerup);
//                    CheckCollisionPowerup(&player,&quantity_powerup);
                 //    trap->SetScroll(scroll_three);
                   //  trap->Render(frame, gRenderer);
                    //CheckCollisionTraps(aladdin, trap);
           /*2*/  //  paan2.SetScroll(scroll_two);
                   // paan.Render(frame, gRenderer);
                        //Gutter
                //    gutter1.SetScroll(scroll_two);
                  //  gutter1.Render(frame,gRenderer);
                   // CheckCollisionTraps(aladdin, &gutter1);
                    buttons = game_screen.GetButtons();
                    for (int i =0; i < game_screen.GetButtonCount(); i++)
                    {
                        if (buttons[i].GetState() == 2)
                        {
                            if (i==0)
                            {
                                is_pause = true;
                            }
                        }
                    }

                    if ((aladdin->GetX()) < SCREEN_WIDTH/2)
                    {
                        aladdin->move();
                    }

                    if (aladdin->GetX() >= SCREEN_WIDTH/2)
                    {
                        if (aladdin->movement)
                        {
                            if (aladdin->direction == 0)
                            {
                                scroll_one= scroll_one - 0.1;
                                scroll_two = scroll_two - 0.3;
                                scroll_three = scroll_three - 0.5;
                                ObjectList->Move(RIGHT);
                            }
                            else if (aladdin->direction == 1 && scroll_three <-10)
                            {
                                scroll_one= scroll_one + 0.1;
                                scroll_two = scroll_two + 0.3;
                                scroll_three = scroll_three + 0.5;
                                ObjectList->Move(LEFT);
                            }
                            else
                            {
                                aladdin->SetX(-1);
                            }
                        }
                    }
				    //Scroll background with parallax
                    if( scroll_one < -game_texture_one.GetWidth() )
                    {
                        scroll_one = 0;
                    }
                    if( scroll_three < -game_texture_three.GetWidth()/2)
                    {
                        scroll_three = 0;
                    }
                    if (scroll_two < -game_texture_two.GetWidth() || !aladdin->GetLife())
                    {
                        game_over = true;
                        is_game = false;
                    }

                    //Render background
                    float new_scroll_one = scroll_one + game_texture_one.GetWidth();
                    float new_scroll_two = scroll_two + game_texture_two.GetWidth();
                    float new_scroll_three = scroll_three + game_texture_three.GetWidth();
                    //player.Render(frame,gRenderer);
                    game_screen.Render(frame, new_scroll_one,new_scroll_two, new_scroll_three, gRenderer );

                }

                if(is_pause) //checks if game paused
                {
                    pause_screen_texture.SetAlpha(230);
                    pause_screen.Render(frame, gRenderer);
                    buttons = pause_screen.GetButtons();
                    for (int i =0; i < pause_screen.GetButtonCount(); i++) //loops over buttons and implements the button functionality
                    {
                        if (buttons[i].GetState() == 2)
                        {
                            if (i==0)
                            {
                                is_pause = false;

                            }
                            if(i==1)
                            {
                                is_game = false;
                                is_pause = false;
                                is_menu = true;
                                SaveGame(aladdin);
                            }
                        }
                    }
                }
                if (game_over) //checks if game is over
                {
                    int count_button = 2;
                    if (aladdin->GetLife()) //if life is there, it shows player won
                    {
                        game_won_texture.SetAlpha(255);
                        game_won_screen.Render(frame, gRenderer);
                        buttons = game_won_screen.GetButtons();
                    }
                    else //player life is false, game over screen shows up
                    {
                        game_over_texture.SetAlpha(255);
                        game_over_screen.Render(frame, gRenderer);
                        buttons = game_over_screen.GetButtons();
                    }

                    for (int i =0; i < count_button; i++) //loops over buttons and implements the button functionality
                        {
                            if (buttons[i].GetState() == 2)
                            {
                                if (i==0)
                                {
                                    game_over = false;
                                    is_game = true;
                                    scroll_one =0;
                                    scroll_two = 0;
                                    scroll_three = 0;
                                    aladdin->SetX(-1);
                                    aladdin -> SetHealth(3);
                                    aladdin -> SetQuantity(20);
                                }
                                if (i==1)
                                {
                                    is_menu = true;
                                    game_over = false;
                                }
                            }
                        }

                }

                SetAlpha(); //to decrement opaqueness and increment trasparency
                frame++;

                if (frame % 50 == 0)
                {
                    frame = 0;
                }
				//Update screen
				SDL_RenderPresent( gRenderer );
			}
		}
	}
	//Free resources and close SDL
	close();

	return 0;
}

void CheckCollisionTraps(Player* player, Traps* trap)
{
    int x = (int)player->GetX();
    int y = (int)player->GetY();
    SDL_Rect player_rect = {x-(int)scroll_two,y,70, 115};
    SDL_Rect trap_rect = {(int)trap->GetX(), (int)trap->GetY(),17,5};

    if (SDL_HasIntersection(&player_rect, &trap_rect))
    {
        if (trap->GetStrType() == PAAN)
        {
           // trap->GetTexture()->Free();
            player->SetHealth(-1);
            std::cout << "Health: " << player->GetHealth() << std::endl;
            cout<<player->GetLife()<<endl;
        }
        else if (trap->GetStrType() == GUTTER)
        {
            player->SetHealth(0);
        }
    }
}


void CheckCollisionPowerup(Player* player, Powerup* powerup)
{
    int x = (int)player->GetX();
    int y = (int)player->GetY();
    SDL_Rect player_rect = {x-(int)scroll_two,y,70, 115};
    SDL_Rect powerup_rect = {(int)powerup->GetX(), (int)powerup->GetY(), (int)powerup->GetFrameWidth(), (int)powerup->GetFrameHeight()};

    if (SDL_HasIntersection(&player_rect, &powerup_rect))
    {
        if (powerup->GetType() == HEALTHPOWERUP)
        {
            player->SetHealth(1);
            powerup->GetTexture()->Free();

        }
        else if (powerup->GetType() == QUANTITYPOWERUP)
        {
            player->SetQuantity(1);
            powerup->GetTexture()->Free();

        }

        else if (powerup->GetType() == STRENGTHPOWERUP)
        {
            player->SetStrength();
            powerup->GetTexture()->Free();
        }
    }
}

void SetAlpha()
{
    ///Cap if below 0
    if( opaque - 3 < 0 )
    {
        opaque = 0;
    }
    ///Decrement otherwise
    else
    {
        opaque -= 0.2;
    }
    ///Cap if above 255
    if( trasparency+ 3 > 255 )
    {
        trasparency=255;
    }
    ///Increment otherwise
    else
    {
        trasparency += 0.2;
    }
}
