#ifndef GAME_H
#define GAME_H
#include "Player.h"
#include"Powerup.h"


class Game
{
    public:
        Game();
        Player* NewGame(LTexture*, LTexture*, LTexture*, LTexture*, LTexture*);
        bool CheckCollisionPowerup(Player* player, Powerup* powerup);
        virtual ~Game();

    protected:

    private:
        Player* player;

};

#endif // GAME_H
