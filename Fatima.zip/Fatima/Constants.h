#pragma once
const int SCREEN_WIDTH = 1024;
const int SCREEN_HEIGHT = 576;
const float WORLD_COORD_CHANGE_PER_CLICK = 1;
