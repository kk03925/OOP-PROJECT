#ifndef StrengthBar_H
#define StrengthBar_H
#include "BarClass.h"

class StrengthBar: public BarClass
{
    public:
        StrengthBar();
        StrengthBar(LTexture*, LTexture*,float, float);
        void Render(long int&, int, SDL_Renderer*);
        void operator = (const StrengthBar& cpy);
        virtual ~StrengthBar();
    private:
        int time = 20;
};

#endif // StrengthBar_H
