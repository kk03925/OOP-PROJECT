#ifndef WEAPONS_H
#define WEAPONS_H
#include "Object.h"
#include "LTexture.h"

class Weapons : public Object
{
    public:
        Weapons(LTexture*,float,float,float,float);
        ~Weapons();

    protected:


    private:


};

#endif // WEAPONS_H
