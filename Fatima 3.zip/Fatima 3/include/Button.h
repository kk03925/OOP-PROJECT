#ifndef BUTTON_H
#define BUTTON_H
#include "LTexture.h"
#include "Word.h"

//enum State{Normal, Hover, Clicked};

class Button
{
    public:
        Button();
        Button(LTexture*, LTexture*, float, float, string, int type);
        void Init(LTexture*, LTexture*, float, float, string, int type);
        void Render(SDL_Renderer*);
        int GetWidth();
        int GetHeight();
        int GetX();
        int GetY();
        void ChangeState(int);
        string GetText();
        int GetState();
        virtual ~Button();

    protected:

    private:
        Word* word;
        int width;
        int height;
        int type;
        float x;
        float y;
        int state;
        string text;
        SDL_Rect spriteClips[3]; //sprite clips for each state of the button
        LTexture* button_image; //Texture of image consisting of Buttons
        LTexture* text_texture;


};

#endif // BUTTON_H
