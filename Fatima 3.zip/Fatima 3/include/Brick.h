#ifndef BRICK_H
#define BRICK_H
#include "LTexture.h"
#include "GameObject.h"

class Brick : public GameObject
{
    public:
        Brick();
        Brick(LTexture*, float, float);
        string GetStrType();
        void SetScroll(float);
        virtual void Render(long int&, SDL_Renderer*) = 0;
        virtual ~Brick();

    protected:
        float scroll;
        string type;
};

#endif // BRICK_H
