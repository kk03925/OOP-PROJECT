#ifndef SCREEN_H
#define SCREEN_H
#include "LTexture.h"
#include "Button.h"
#include <SDL_mixer.h>


class Screen
{
    public:
        Screen(LTexture*);
        virtual void Render(SDL_Renderer*);
        virtual ~Screen();

    protected:
        LTexture* bg_image;    //background image of the screen
//int button_count;   //no. of Buttons to be rendered
        //Button* buttons[10];

    private:

};

#endif // SCREEN_H
