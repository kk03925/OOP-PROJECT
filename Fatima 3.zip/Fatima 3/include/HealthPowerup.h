#ifndef HEALTHPOWERUP_H
#define HEALTHPOWERUP_H

#include "Powerup.h"

class HealthPowerup: public Powerup
{
    public:
        HealthPowerup();
        HealthPowerup(LTexture*, float, float);
        void Render(long int&, SDL_Renderer*);
        virtual ~HealthPowerup();

    protected:

    private:
};

#endif // HEALTHPOWERUP_H
