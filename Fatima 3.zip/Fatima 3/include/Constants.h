#pragma once
const float WORLD_COORD_CHANGE_PER_CLICK = 1;
