#ifndef TRAPS_H
#define TRAPS_H


class Traps : public GameObject
{
    public:
        Traps();
        Traps(LTexture*, float, float);
        virtual void Render(long int&, SDL_Renderer*) = 0;
        string GetType();
        void SetScroll(float);
        virtual ~Traps();

    protected:
        string type;
        float scroll;
};

#endif // TRAPS_H
