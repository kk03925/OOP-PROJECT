#ifndef MENUSCREEN_H
#define MENUSCREEN_H
#include "Screen.h"
#include "LTexture.h"
#include <SDL_mixer.h>
#include "Button.h"

class MenuScreen: public Screen
{
    public:
        MenuScreen(LTexture*,LTexture*, LTexture*);
        virtual ~MenuScreen();
        virtual void Render(SDL_Renderer*);
        Button* GetButtons();   //returns array of buttons
        int GetButtonCount();   //return the no. of buttons to be rendered
        void ChangeButtonState(int val, int ind); //changes the state of Button on the index
        void MouseMotion(int x, int y); //used to handle mouse motion events on a screen
        void MouseClick(int x, int y, Mix_Chunk*); //used to handle mouse click events on a screen

    protected:
        LTexture* button_sprite; //the small screen over which buttons are drawn
        LTexture* text_sprite;
        Button* buttons;
        int button_count;
};

#endif // MENUSCREEN_H
