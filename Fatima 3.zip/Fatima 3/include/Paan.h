#ifndef PAAN_H
#define PAAN_H


class Paan : public Traps
{
    public:
        Paan();
        Paan(LTexture*, float, float);
        virtual ~Paan();

    protected:
        const int damage = 1;
    private:
};

#endif // PAAN_H
