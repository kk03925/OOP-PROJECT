#ifndef SPLASHSCREEN_H
#define SPLASHSCREEN_H
#include "Ltexture.h"
#include "Screen.h"


class SplashScreen: public Screen
{
    public:
        SplashScreen(LTexture*);
        virtual ~SplashScreen();
        void Render(SDL_Renderer* gRenderer);

    protected:

    private:

};

#endif // SPLASHSCREEN_H
