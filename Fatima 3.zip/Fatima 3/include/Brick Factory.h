#ifndef BRICK FACTORY_H
#define BRICK FACTORY_H
#include "Brick.h"

class Brick Factory
{
    public:
        Brick Factory();
        Brick* getBrick(int type);
        virtual ~Brick Factory();

    protected:

    private:
        Brick* brick;

};

#endif // BRICK FACTORY_H
