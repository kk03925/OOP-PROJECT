#ifndef STANDARDBRICK_H
#define STANDARDBRICK_H
#include "Brick.h"

class StandardBrick : public Brick
{
    public:
        StandardBrick();
        StandardBrick(LTexture*, float, float);
        virtual ~StandardBrick();
        void Render(long int& frame,SDL_Renderer* gRenderer);
};

#endif // STANDARDBRICK_H
