#ifndef FACTORYPRODUCER_H
#define FACTORYPRODUCER_H


class FactoryProducer
{
    public:
        FactoryProducer();
        virtual ~FactoryProducer();

    protected:

    private:
};

#endif // FACTORYPRODUCER_H
