#ifndef POWERUP_H
#define POWERUP_H
#include "LTexture.h"
#include "GameObject.h"


class Powerup: public GameObject
{
    public:
        Powerup();
        Powerup(LTexture*, float, float);
        string GetType();
        void SetScroll(float scroll);
        virtual void Render(long int&, SDL_Renderer*) = 0;
        virtual ~Powerup();

    protected:
        string type;
        float scroll;

    private:
};

#endif // POWERUP_H
