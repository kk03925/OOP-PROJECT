#ifndef CHARACTER_H
#define CHARACTER_H
#include "LTexture.h"


class Character
{
    public:
        Character();
        Character(LTexture* image, float x, float y, int);
        void Render(SDL_Renderer* gRenderer, bool debug);
        void operator = (const Character& cpy);
        virtual ~Character();

    protected:

    private:
        int x;
        int y;
        int width;
        int height;
        SDL_Rect sprite_clips;
        LTexture* image;
        int ascii;

};

#endif // CHARACTER_H
