#ifndef MOVINGBRICK_H
#define MOVINGBRICK_H
#include "Brick.h"
class MovingBrick : public Brick
{
    public:
        MovingBrick();
        MovingBrick(LTexture*, float, float, int, int);
        void Move();
        void Render(long int& frame,SDL_Renderer* gRenderer);
        virtual ~MovingBrick();
    private:
        const int vel = 100;
        bool maxi = false;
        int moving = 0;
        int maxim;
        int minum;

};

#endif // MOVINGBRICK_H
