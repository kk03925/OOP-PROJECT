#include "MovingBrick.h"

MovingBrick::MovingBrick()
{
    //ctor
}

MovingBrick::MovingBrick(LTexture* image, float x, float y, int minum, int maxim) : Brick(image, x, y)
{
    this->image = image;
    this->x = x;
    this->y = y;
    this->type = "moving";
    this->maxim = maxim;
    this->minum = minum;
}

void MovingBrick::Move()
{
    //increment and decrement the x-axis repeatedly
    if(maxim == false & moving == 0)
    {
        std::cout <<"OUT 1"<<std::endl;
        this->x = x + vel;
        if(this->x >= maxim)
        {
            std::cout <<"OUT 2"<<std::endl;
            moving = 1;
            maxi = true;
        }
    }
    else if(maxim == true & moving == 1)
    {
        std::cout <<"IN 1"<<std::endl;
        this->x = x - vel;
        if(this->x <= minum)
        {
            std::cout <<"IN 2"<<std::endl;
            moving = 0;
            maxi = false;
        }
    }
}

void MovingBrick::Render(long int& frame,SDL_Renderer* gRenderer)
{
//    int mov_dir = 1;
//
//    if (mov_dir == 1)
//    {
//        //std::cout << "Move Right" << std::endl;
//        image->RenderTexture(x+vel, y, gRenderer, NULL, 0, NULL, 0.25);
//    }
//    else
//    {
//        image->RenderTexture(x-vel, y, gRenderer, NULL, 0, NULL, 0.25);
//    }
//    if (this->x <= 200 || this->x >= 800)
//    {
//        mov_dir *= -1;
//    }
        image->RenderTexture(x+vel, y, gRenderer, NULL, 0, NULL, 0.25);
}

MovingBrick::~MovingBrick()
{
    //dtor
}
