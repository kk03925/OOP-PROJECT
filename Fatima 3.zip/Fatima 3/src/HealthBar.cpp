#include "HealthBar.h"

HealthBar::HealthBar(): BarClass()
{

}

HealthBar::HealthBar(LTexture* image, LTexture* health,float x, float y): BarClass(image, icon_image)
{
    this -> image = image;
    this -> icon_image = health;
    this -> x = x;
    this -> y = y;
}

void HealthBar::Render(long int&, int health, SDL_Renderer* gRenderer)
{
    bar = {(int)x,(int)y, health*100 , 25};
    image-> RenderTexture(0, 0,gRenderer, &bar, 0, NULL, 1);
    icon_image-> RenderTexture(3*100,0, gRenderer,NULL, 0, NULL, 0.06);
}

void HealthBar::operator = (const HealthBar& cpy)
{
    this -> image = cpy.image;
    this -> icon_image = cpy.icon_image;
    this -> x = x;
    this -> y = y;

}


HealthBar::~HealthBar()
{
    //dtor
}
