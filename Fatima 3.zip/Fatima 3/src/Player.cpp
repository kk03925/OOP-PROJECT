#include "Player.h"

Player::Player(LTexture* image, HealthBar* health_bar, QuantityBar* quantity_bar): GameObject(image)
{
    this->image = image;
    milk_quantity = 19;
    health = 100;
    this -> health_bar = health_bar;
    this -> quantity_bar = quantity_bar;
    x = 0;
    y = 400;
    //Set sprite clips
    gStandingSpriteClips [ 0 ].x = 38;
    gStandingSpriteClips [ 0 ].y = 41;
    gStandingSpriteClips [ 0 ].w = 50;
    gStandingSpriteClips [ 0 ].h = 122;

    gStandingSpriteClips [ 1 ].x = 1200;
    gStandingSpriteClips [ 1 ].y = 38;
    gStandingSpriteClips [ 1 ].w = 48;
    gStandingSpriteClips [ 1 ].h = 123;

    gWalkingRightSpriteClips[ 0 ].x =   45;
    gWalkingRightSpriteClips[ 0 ].y =   176;
    gWalkingRightSpriteClips[ 0 ].w =  64;
    gWalkingRightSpriteClips[ 0 ].h = 115;

    gWalkingRightSpriteClips[ 1 ].x =   117;
    gWalkingRightSpriteClips[ 1 ].y =   179;
    gWalkingRightSpriteClips[ 1 ].w =  55;
    gWalkingRightSpriteClips[ 1 ].h = 112;

    gWalkingRightSpriteClips[ 2 ].x =   187;
    gWalkingRightSpriteClips[ 2 ].y =   177;
    gWalkingRightSpriteClips[ 2 ].w =  52;
    gWalkingRightSpriteClips[ 2 ].h = 117;

    gWalkingRightSpriteClips[ 3 ].x =   248;
    gWalkingRightSpriteClips[ 3 ].y =   179;
    gWalkingRightSpriteClips[ 3 ].w =  65;
    gWalkingRightSpriteClips[ 3 ].h = 118;

    gWalkingRightSpriteClips[ 4 ].x =   324;
    gWalkingRightSpriteClips[ 4 ].y =   181;
    gWalkingRightSpriteClips[ 4 ].w =  78;
    gWalkingRightSpriteClips[ 4 ].h = 113;

    gWalkingRightSpriteClips[ 5 ].x =   413;
    gWalkingRightSpriteClips[ 5 ].y =   176;
    gWalkingRightSpriteClips[ 5 ].w =  72;
    gWalkingRightSpriteClips[ 5 ].h =  118;

    gWalkingRightSpriteClips[ 6 ].x =   499;
    gWalkingRightSpriteClips[ 6 ].y =   178;
    gWalkingRightSpriteClips[ 6 ].w =  61;
    gWalkingRightSpriteClips[ 6 ].h = 115;

    gWalkingRightSpriteClips[ 7 ].x =   571;
    gWalkingRightSpriteClips[ 7 ].y =   178;
    gWalkingRightSpriteClips[ 7 ].w =  48;
    gWalkingRightSpriteClips[ 7 ].h = 112;

    gWalkingRightSpriteClips[ 8 ].x =   628;
    gWalkingRightSpriteClips[ 8 ].y =   170;
    gWalkingRightSpriteClips[ 8 ].w =  58;
    gWalkingRightSpriteClips[ 8 ].h = 121;

    gWalkingRightSpriteClips[ 9 ].x =   694;
    gWalkingRightSpriteClips[ 9 ].y =   169;
    gWalkingRightSpriteClips[ 9 ].w =  74;
    gWalkingRightSpriteClips[ 9 ].h =   120;

    gWalkingRightSpriteClips[ 10 ].x =   772;
    gWalkingRightSpriteClips[ 10 ].y =   178;
    gWalkingRightSpriteClips[ 10 ].w =  81;
    gWalkingRightSpriteClips[ 10 ].h = 115;

    gWalkingRightSpriteClips[ 11 ].x =   869;
    gWalkingRightSpriteClips[ 11 ].y =   173;
    gWalkingRightSpriteClips[ 11 ].w =  66;
    gWalkingRightSpriteClips[ 11 ].h = 118;

    gWalkingLeftSpriteClips[ 0 ].x =   1935;
    gWalkingLeftSpriteClips[ 0 ].y =   175;
    gWalkingLeftSpriteClips[ 0 ].w =  65;
    gWalkingLeftSpriteClips[ 0 ].h = 116;

    gWalkingLeftSpriteClips[ 1 ].x =   1870;
    gWalkingLeftSpriteClips[ 1 ].y =   176;
    gWalkingLeftSpriteClips[ 1 ].w =  57;
    gWalkingLeftSpriteClips[ 1 ].h = 113;

    gWalkingLeftSpriteClips[ 2 ].x =   1807;
    gWalkingLeftSpriteClips[ 2 ].y =   175;
    gWalkingLeftSpriteClips[ 2 ].w =  52;
    gWalkingLeftSpriteClips[ 2 ].h = 118;

    gWalkingLeftSpriteClips[ 3 ].x =   1733;
    gWalkingLeftSpriteClips[ 3 ].y =   176;
    gWalkingLeftSpriteClips[ 3 ].w =  65;
    gWalkingLeftSpriteClips[ 3 ].h = 121;


    gWalkingLeftSpriteClips[ 4 ].x =   1644;
    gWalkingLeftSpriteClips[ 4 ].y =   179;
    gWalkingLeftSpriteClips[ 4 ].w =  79;
    gWalkingLeftSpriteClips[ 4 ].h = 115;

    gWalkingLeftSpriteClips[ 5 ].x =   1560;
    gWalkingLeftSpriteClips[ 5 ].y =   177;
    gWalkingLeftSpriteClips[ 5 ].w =  75;
    gWalkingLeftSpriteClips[ 5 ].h = 117;

    gWalkingLeftSpriteClips[ 6 ].x =   1483;
    gWalkingLeftSpriteClips[ 6 ].y =   176;
    gWalkingLeftSpriteClips[ 6 ].w =  64;
    gWalkingLeftSpriteClips[ 6 ].h = 114;

    gWalkingLeftSpriteClips[ 7 ].x =   1424;
    gWalkingLeftSpriteClips[ 7 ].y =   176;
    gWalkingLeftSpriteClips[ 7 ].w =  54;
    gWalkingLeftSpriteClips[ 7 ].h = 114;

    gWalkingLeftSpriteClips[ 8 ].x =   1359;
    gWalkingLeftSpriteClips[ 8 ].y =   171;
    gWalkingLeftSpriteClips[ 8 ].w =  60;
    gWalkingLeftSpriteClips[ 8 ].h = 121;

    gWalkingLeftSpriteClips[ 9 ].x =   1278;
    gWalkingLeftSpriteClips[ 9 ].y =   168;
    gWalkingLeftSpriteClips[ 9 ].w =  72;
    gWalkingLeftSpriteClips[ 9 ].h = 122;

    gWalkingLeftSpriteClips[ 10 ].x =   1192;
    gWalkingLeftSpriteClips[ 10 ].y =   178;
    gWalkingLeftSpriteClips[ 10 ].w =  82;
    gWalkingLeftSpriteClips[ 10 ].h = 115;

    gWalkingLeftSpriteClips[ 11 ].x =   1109;
    gWalkingLeftSpriteClips[ 11 ].y =   172;
    gWalkingLeftSpriteClips[ 11 ].w =  66;
    gWalkingLeftSpriteClips[ 11 ].h =   121;

    alive = true;
}

void Player::Render(long int& frame, SDL_Renderer* gRenderer)
{
    if (frame % 10 == 0)
    {
        AnimationFrame++; //to control speed of the clips rendering of the ghosts
    }

    if (alive)
    {
        if (movement==true)
        {
            if (direction==0)
            {
                image->RenderTexture(x,y, gRenderer,&gWalkingRightSpriteClips[AnimationFrame%12],0, NULL, 1);
            }
            else if (direction == 1 )
            {
                image->RenderTexture(x,y, gRenderer,&gWalkingLeftSpriteClips[AnimationFrame%12],0, NULL, 1);
            }
        }
        else
        {
            image->RenderTexture(x,y, gRenderer,&gStandingSpriteClips[direction],0, NULL, 1);
        }
    }

    if (AnimationFrame >= 12)
    {
        AnimationFrame = 0;
    }
    health_bar -> Render(frame, health, gRenderer);
    quantity_bar -> Render(frame, milk_quantity, gRenderer);
}

void Player::handleEvent(SDL_Event& e)
{
    if (e.type == SDL_KEYDOWN && e.key.repeat ==0)
    {
        switch (e.key.keysym.sym)
        {
            case (SDLK_LEFT ) :
            {
                cout<<"in left"<<endl;
                direction = 1;
                movement = true;
                mVelX -= PlayerVelocity;
                break;
            }
            case (SDLK_RIGHT) :
            {
                direction= 0;
                movement = true;
                mVelX += PlayerVelocity;
                break;
            }
        }
    }
    else if (e.type == SDL_KEYUP && e.key.repeat ==0)
    {
        switch (e.key.keysym.sym)
        {
            case (SDLK_LEFT)  :
            {
                movement = false;
                mVelX += PlayerVelocity;
                break;
            }
            case (SDLK_RIGHT) :
            {
                movement = false;
                mVelX -= PlayerVelocity;
                break;
            }
        }
    }
}

void Player::move()
{
    if (collision == false)
    {
        x +=mVelX;
    }
}

Player::~Player()
{
    cout<<"Aladdin destroyed"<<endl;
}

void Player::SetHealth(int effect)
{
    if (health < 3 & effect == 1)
    {
        health = health + effect;
    }
    else if (effect == -1)
    {
        health = health + effect;
    }
    else if (effect == 0)
    {
        health = 0;
    }
    if (health <= 0)
    {
        alive = false;
    }
}

void Player::SetQuantity()
{
    if (milk_quantity <20)
    {
        milk_quantity++;
    }
}

bool Player::GetLife()
{
    return alive;

}

int Player::GetHealth()
{
    return health;
}
