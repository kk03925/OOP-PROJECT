#include "Paan.h"

Paan::Paan()
{
    //ctor
}

Paan::Paan(LTexture* image, float x, float y) : Traps(image, x, y)
{
    this->image = image;
    this->x = x;
    this->y = y;
    thi
}

Paan::~Paan()
{
    //dtor
}
