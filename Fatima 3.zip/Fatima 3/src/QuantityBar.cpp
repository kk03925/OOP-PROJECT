#include "QuantityBar.h"

QuantityBar::QuantityBar(): BarClass()
{

}

QuantityBar::QuantityBar(LTexture* image, LTexture* milk, float x, float y): BarClass(image, icon_image)
{
    this -> image = image;
    this ->icon_image = milk;
    this -> x = x;
    this -> y = y;

}

void QuantityBar::Render(long int&, int quantity, SDL_Renderer* gRenderer)
{
    bar = {(int)x,(int)y, quantity*25 , 25};
    image-> RenderTexture(0,25,gRenderer, &bar, 0, NULL, 1);
    icon_image-> RenderTexture(20*25,25,gRenderer, NULL, 0, NULL, 0.1);

}

void QuantityBar::operator = (const QuantityBar& cpy)
{
    this -> image = cpy.image;
    this -> icon_image = cpy.icon_image;
    this -> x = x;
    this -> y = y;

}

QuantityBar::~QuantityBar()
{
    //dtor
}

