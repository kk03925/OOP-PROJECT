#include "Traps.h"

Traps::Traps()
{
    //ctor
}

Traps::Traps(Ltexture* image, float x, float y) : GameObject(image)
{
    this->image = image;
    this->x = x;
    this->y = y;
}

void Traps::SetScroll(float scroll)
{
    this->scroll = scroll;
}

void Powerup::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x, y,gRenderer, NULL , 0, NULL, 1);
}

string Powerup::GetType()
{
    return type;
}

Traps::~Traps()
{
    //dtor
}
