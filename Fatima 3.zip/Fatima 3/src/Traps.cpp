#include "Traps.h"

Traps::Traps()
{
    //ctor
}

Traps::Traps(LTexture* image, float x, float y) : GameObject(image)
{
    this->image = image;
    this->x = x;
    this->y = y;
    this->scroll = 0;
}

void Traps::SetScroll(float scroll)
{
    this->scroll = scroll;
}

void Traps::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x, y,gRenderer, NULL , 0, NULL, 1);
}

string Traps::GetStrType()
{
    return type;
}

Traps::~Traps()
{
    //dtor
}
