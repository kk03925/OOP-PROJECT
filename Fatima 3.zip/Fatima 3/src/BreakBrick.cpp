#include "BreakBrick.h"

BreakBrick::BreakBrick()
{
    //ctor
}

BreakBrick::BreakBrick(LTexture* image, float x, float y) : Brick(image, x, y)
{\
    this->image = image;
    this->x = x;
    this->y = y;
    this->type = "break";
}

void BreakBrick::Render(long int& frame,SDL_Renderer* gRenderer)
{
    image->RenderTexture(x+scroll, y, gRenderer, NULL, 0, NULL, 0.25);
}

void BreakBrick::Break()
{
    this->image->Free();
}
BreakBrick::~BreakBrick()
{
    //dtor
}
