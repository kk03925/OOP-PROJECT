#include "Brick.h"


Brick::Brick()
{
    x = 0;
    y = 0;
    scroll = 0;
    image = NULL;
}
Brick::Brick(LTexture* image, float x, float y) : GameObject(image)
{
    this->image = image;
    this->x = x;
    this->y = y;
}

void Brick::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x, y,gRenderer, NULL , 0, NULL, 0.25);
}

string Brick::GetStrType()
{
    return type;
}

void Brick::SetScroll(float scroll)
{
    this->scroll = scroll;
}

Brick::~Brick()
{
   // cout<< "Brick Destructor" <<endl;
}
