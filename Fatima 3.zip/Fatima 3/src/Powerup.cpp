#include "Powerup.h"

Powerup::Powerup(): GameObject()
{
    //ctor
}

Powerup::Powerup(LTexture* image, float x, float y): GameObject(image)
{
    this -> image = image;
    this -> x = x;
    this -> y = y;
    this -> scroll = 0;
}

void Powerup::Render(long int& frame, SDL_Renderer* gRenderer)
{
    image->RenderTexture(x, y,gRenderer, NULL , 0, NULL, 1);
}

string Powerup::GetType()
{
    return type;
}

void Powerup::SetScroll(float scroll)
{
    this->scroll = scroll;
}

Powerup::~Powerup()
{
    //dtor
}
