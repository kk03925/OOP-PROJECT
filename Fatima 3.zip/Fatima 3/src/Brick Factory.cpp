#include "Brick Factory.h"
#include "StandardBrick.h"
#include "BreakBrick.h"
#include "MovingBrick.h"

Brick Factory::Brick Factory()
{
    //ctor
}
Brick* Brick Factory::getBrick()
{
    if (type == 0)
    {
        brick = new StandardBrick(image, x, y);
    }
    else if (type == 1)
    {
        brick = new BreakBrick(image, x, y);
    }
    else if (type == 2)
    {
        brick = new MovingBrick(image, x, y, minimum, maximum);
    }
    return brick;
}
Brick Factory::~Brick Factory()
{
    //dtor
}
